package com.elanduas.model;


public class SystemResource {

	private Long resourceDetailId;
	Systems system;
	Resource resource;
	private Long[] system_id;
	private Long[] resource_id;
	
	public Long getResourceDetailId() {
		return resourceDetailId;
	}
	public void setResourceDetailId(Long resourceDetailId) {
		this.resourceDetailId = resourceDetailId;
	}
	public Systems getSystem() {
		return system;
	}
	public void setSystem(Systems system) {
		this.system = system;
	}
	public Resource getResource() {
		return resource;
	}
	public void setResource(Resource resource) {
		this.resource = resource;
	}
	public Long[] getSystem_id() {
		return system_id;
	}
	public void setSystem_id(Long[] system_id) {
		this.system_id = system_id;
	}
	public Long[] getResource_id() {
		return resource_id;
	}
	public void setResource_id(Long[] resource_id) {
		this.resource_id = resource_id;
	}
}
