package com.elanduas.model;


public class Role {

	private Long roleId;
	private Long number;
	private String name;
	private Long isUse;
	private String description;
	private Integer userCount;
	private Integer roleCount;
	
	public Long getRoleId() {
		return roleId;
	}
	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}
	public Long getNumber() {
		return number;
	}
	public void setNumber(Long number) {
		this.number = number;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Long getIsUse() {
		return isUse;
	}
	public void setIsUse(Long isUse) {
		this.isUse = isUse;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Integer getUserCount() {
		return userCount;
	}
	public void setUserCount(Integer userCount) {
		this.userCount = userCount;
	}
	public Integer getRoleCount() {
		return roleCount;
	}
	public void setRoleCount(Integer roleCount) {
		this.roleCount = roleCount;
	}
	
	
}
