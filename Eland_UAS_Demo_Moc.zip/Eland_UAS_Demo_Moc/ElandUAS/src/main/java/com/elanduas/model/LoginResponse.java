package com.elanduas.model;

public class LoginResponse {

}
