package com.elanduas.controller;

import java.io.UnsupportedEncodingException;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.codehaus.jackson.map.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.elanduas.model.LoginRequest;
import com.elanduas.model.Resource;
import com.elanduas.model.SystemResource;
import com.elanduas.model.Systems;
import com.elanduas.model.User;
import com.elanduas.model.UserSystemRole;
import com.elanduas.reqrespmodel.CommonResponse;
import com.elanduas.reqrespmodel.GetInfoMinimulRequest;
import com.elanduas.reqrespmodel.SystemRoleResponse;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;

@Controller
public class UASController {

	String userKey = "userLoginresponse";
	String accessTkn = null;
	private static final String localURL = "http://localhost:8081/";
	// private static final String localURL = "http://13.209.161.153:8081/";
	private static final String domainPath = "uas/";
	String apiPath = null;
	String url = null;
	HttpClient httpclient;
	HttpPost post;
	HttpResponse httpResponse;
	JSONObject json;
	StringEntity stringEntityinput = null;
	JSONArray jsonArray;
	String json_string;
	HttpSession session;
	boolean accessToken = false;

	@RequestMapping(value = "/", method = RequestMethod.GET)
	public String preLogin(Model model) {
		LoginRequest loginRequest = new LoginRequest();
		model.addAttribute("loginForm", loginRequest);
		return "login";
	}

	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logout(HttpServletRequest request, Model model) {

		return "redirect:";
	}

	@RequestMapping(value = "/dashboard", method = RequestMethod.GET)
	public String dashbrdget(Model model) {
		List<Systems> systemList = getSystemDetail();
		model.addAttribute("systemList", systemList);
		return "Dashboard";
	}

	@RequestMapping(value = "/forgotPassword", method = RequestMethod.POST)
	public String forgotPassword(HttpServletRequest request, Model model) {
		return "login";
	}

	@RequestMapping(value = "/changePassword", method = RequestMethod.GET)
	public String changePassword(Model model) {
		return "ChangePassword";
	}

	@RequestMapping(value = "/changePassword", method = RequestMethod.POST)
	public String changePasswordPost(HttpServletRequest request, Model model) {

		apiPath = "changeUserPw";
		url = localURL + apiPath;
		String httpResponseJson = null;
		httpclient = new DefaultHttpClient();
		json = new JSONObject();
		post = new HttpPost(url);
		CommonResponse responseObj = null;
		try {
			json.put("oldPassword", request.getParameter("oldPassword"));
			json.put("newPassword", request.getParameter("newPassword"));
			json.put("userId", request.getParameter("userId"));
			stringEntityinput = new StringEntity(json.toString());
			stringEntityinput.setContentType("application/json");
			post.addHeader("Accept", "application/json");
			post.addHeader("Content-Type", "application/json");
			post.setEntity(stringEntityinput);
			httpResponse = httpclient.execute(post);
			httpResponseJson = EntityUtils.toString(httpResponse.getEntity());
			System.out.println(httpResponseJson);
			JsonElement newJson = new com.google.gson.JsonParser().parse(httpResponseJson);
			Gson gson = new Gson();
			responseObj = gson.fromJson(newJson, CommonResponse.class);

		} catch (Exception e) {
			return "login";
		}
		if (Integer.parseInt(responseObj.getCode()) != 200) {
			model.addAttribute("errorMessage", responseObj.getMessage());
		}
		return "redirect:dashboard";
	}

	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public String login1Post(HttpServletRequest request, Model model) {
		return "redirect:dashboard";
	}

	@RequestMapping(value = "/login1", method = RequestMethod.POST)
	public String loginPost(HttpServletRequest request, Model model) {

		// HttpSession session = request.getSession();
		// String sessionAccessTkn = (String)session.getAttribute("acccessToken");
		apiPath = "login";
		url = localURL + apiPath;
		String httpResponseJson = null;
		httpclient = new DefaultHttpClient();
		json = new JSONObject();
		post = new HttpPost(url);
		InetAddress localhost = null;
		CommonResponse responseObj = null;
		try {
			localhost = InetAddress.getLocalHost();
		} catch (UnknownHostException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		System.out.println("System IP Address : " + (localhost.getHostAddress()).trim());
		try {
			json.put("userLogId", request.getParameter("userId"));
			json.put("password", request.getParameter("userPw"));
			stringEntityinput = new StringEntity(json.toString());
			stringEntityinput.setContentType("application/json");
			post.addHeader("Accept", "application/json");
			post.addHeader("Content-Type", "application/json");
			post.setEntity(stringEntityinput);
			httpResponse = httpclient.execute(post);
			httpResponseJson = EntityUtils.toString(httpResponse.getEntity());
			System.out.println(httpResponseJson);
			JsonElement newJson = new com.google.gson.JsonParser().parse(httpResponseJson);
			Gson gson = new Gson();
			responseObj = gson.fromJson(newJson, CommonResponse.class);

		} catch (Exception e) {
			return "login";
		}

		System.out.println(Integer.parseInt(responseObj.getCode()));
		System.out.println(responseObj.isOtpUse());
		if (Integer.parseInt(responseObj.getCode()) == 200 && responseObj.isOtpUse() == false) {
			accessTkn = responseObj.getAccessToken();
			session = request.getSession(true);
			session.setAttribute("accessToken", accessTkn);
			return "redirect:dashboard";
		} else {
			model.addAttribute("errorMsg", responseObj.getMessage());
			return "login";
		}
	}

	@RequestMapping(value = "/addSystem", method = RequestMethod.GET)
	public String addSystemGet(Model model, RedirectAttributes attributes) {
		model.addAttribute("system", new Systems());
		return "AddSystem";
	}

	@RequestMapping(value = "/addSystemOtp", method = RequestMethod.GET)
	public String addSystemOtpGet(HttpServletRequest request, Model model) {
		try {
			List<Systems> systemList = getSystemDetail();
			model.addAttribute("systemList", systemList);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("system", new Systems());
		return "AddSystemOtp";
	}

	@RequestMapping(value = "/addSystemOtp", method = RequestMethod.POST)
	public String addSystemPost(HttpServletRequest request, Model model) {
		apiPath = "addSystemOtp";
		url = localURL + domainPath + apiPath;
		String httpResponseJson = null;
		accessToken = true;
		httpclient = new DefaultHttpClient();
		post = new HttpPost(url);
		json = new JSONObject();
		try {
			json.put("ipaddress", request.getParameter("ipAddress"));
			json.put("description", request.getParameter("description"));
			json.put("systemId", request.getParameterValues("systemId"));
			stringEntityinput = new StringEntity(json.toString());
			stringEntityinput.setContentType("application/json");
			HttpSession session = request.getSession(false);
			post.addHeader("Authorization", "Bearer " + (String) session.getAttribute("accessToken") + "");
			post.addHeader("Accept", "application/json");
			post.addHeader("Content-Type", "application/json");
			post.addHeader("accessToken", (String) request.getAttribute("accessToken"));
			post.setEntity(stringEntityinput);
			httpResponse = httpclient.execute(post);
			httpResponseJson = EntityUtils.toString(httpResponse.getEntity());
			System.out.println(httpResponseJson);
		} catch (Exception e) {
			System.out.println(e);
		}
		return "redirect:dashboard";
	}

	@RequestMapping(value = "/addSystem", method = RequestMethod.POST)
	public String addSystemPost(HttpServletRequest request, @ModelAttribute("system") Systems system, Model model,
			RedirectAttributes attributes) {
		apiPath = "addSystem";
		url = localURL + domainPath + apiPath;
		String httpResponseJson = null;
		accessToken = true;
		httpclient = new DefaultHttpClient();
		post = new HttpPost(url);
		json = new JSONObject();
		CommonResponse responseModel = null;
		try {
			json.put("name", system.getName());
			json.put("description", system.getDescription());
			json.put("isUse", system.getIsUse());
			json.put("inOtpUse", system.getInOtpUse());
			json.put("clientId", system.getClientId());
			json.put("clientSecret", system.getClientSecret());
			stringEntityinput = new StringEntity(json.toString());
			stringEntityinput.setContentType("application/json");
			post.addHeader("Accept", "application/json");
			post.addHeader("Content-Type", "application/json");
			post.addHeader("accessToken", "client");
			post.addHeader("clientId", "test");
			post.addHeader("clientSecret", "secret");
			post.setEntity(stringEntityinput);
			httpResponse = httpclient.execute(post);
			httpResponseJson = EntityUtils.toString(httpResponse.getEntity());
			responseModel = new ObjectMapper().readValue(httpResponseJson, CommonResponse.class);

			System.out.println(responseModel);

		} catch (Exception e) {
			System.out.println(e);
			return "redirect:addSystem";
		}
		if (responseModel.isSuccess()) {
			attributes.addFlashAttribute("successMsg", responseModel.getMessage());
			return "redirect:viewSystem";
		} else {
			attributes.addFlashAttribute("errorMsg", responseModel.getMessage());
			return "AddSystem";
		}
	}

	@RequestMapping(value = "/addUser", method = RequestMethod.GET)
	public String addUserGet(Model model) {
		// JSONObject systemList = getSystemDetail();
		try {
			List<SystemRoleResponse> systemRoleList = getSystemRoleDetail();
			System.out.println("System Role Details:" + systemRoleList);
			model.addAttribute("systemRoleList", systemRoleList);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		model.addAttribute("user", new User());
		return "adduser";
	}

	@RequestMapping(value = "/addUser", method = RequestMethod.POST)
	public String addUserPost(HttpServletRequest request, Model model) {

		apiPath = "addUserInfo";
		url = localURL + domainPath + apiPath;
		String httpResponseJson = null;
		httpclient = new DefaultHttpClient();
		post = new HttpPost(url);
		json = new JSONObject();
		try {
			json.put("userId", request.getParameter("userLogId"));
			json.put("userNm", request.getParameter("userName"));
			json.put("userPw", request.getParameter("password"));
			int isUse = Integer.parseInt(request.getParameter("isUse"));
			if (isUse == 0) {
				json.put("useYn", false);
			} else {
				json.put("useYn", true);
			}

			json.put("emailAddress", request.getParameter("email"));
			json.put("applyStartDate", request.getParameter("applyStartDate1"));
			json.put("applyEndDate", request.getParameter("applyEndDate1"));
			json.put("telNo", Long.parseLong(request.getParameter("telephone_No")));
			json.put("mobileNo", Long.parseLong(request.getParameter("mobile")));
			String[] checkboxNamesList = request.getParameterValues("systemRoleId[]");
			json.put("systemRole", checkboxNamesList);
			stringEntityinput = new StringEntity(json.toString());
			stringEntityinput.setContentType("application/json");
			post.addHeader("Accept", "application/json");
			post.addHeader("Content-Type", "application/json");
			post.addHeader("accessToken", "client");
			post.addHeader("clientId", "test");
			post.addHeader("clientSecret", "secret");
			post.setEntity(stringEntityinput);
			httpResponse = httpclient.execute(post);
			httpResponseJson = EntityUtils.toString(httpResponse.getEntity());
			System.out.println(httpResponseJson);
		} catch (Exception e) {
			System.out.println(e);
		}
		return "Dashboard";
	}

	@RequestMapping(value = "/editUser", method = RequestMethod.POST)
	public String changeUserPost(HttpServletRequest request, Model model) {

		apiPath = "changeUserInfo";
		url = localURL + domainPath + apiPath;
		String httpResponseJson = null;
		httpclient = new DefaultHttpClient();
		post = new HttpPost(url);
		json = new JSONObject();
		try {
			json.put("userId", request.getParameter("userLogId"));
			json.put("userNm", request.getParameter("userName"));
			int isUse = Integer.parseInt(request.getParameter("isUse"));
			if (isUse == 0) {
				json.put("useYn", false);
			} else {
				json.put("useYn", true);
			}

			json.put("emailAddress", request.getParameter("email"));
			json.put("useApplyStartDate", request.getParameter("applyStartDate1"));
			json.put("useApplyEndDate", request.getParameter("applyEndDate1"));
			json.put("telNo", Long.parseLong(request.getParameter("telephone_No")));
			json.put("mobileNo", Long.parseLong(request.getParameter("mobile")));
			stringEntityinput = new StringEntity(json.toString());
			stringEntityinput.setContentType("application/json");
			post.addHeader("Accept", "application/json");
			post.addHeader("Content-Type", "application/json");
			post.addHeader("accessToken", "client");
			post.addHeader("clientId", "test");
			post.addHeader("clientSecret", "secret");
			post.setEntity(stringEntityinput);
			httpResponse = httpclient.execute(post);
			httpResponseJson = EntityUtils.toString(httpResponse.getEntity());
			System.out.println(httpResponseJson);
		} catch (Exception e) {
			System.out.println(e);
		}
		return "Dashboard";
	}

	@RequestMapping(value = "/addRole", method = RequestMethod.GET)
	public String addRoleGet(Model model) {
		// model.addAttribute("role", new Role());
		List<Systems> systemList = getSystemDetail();
		model.addAttribute("systemList", systemList);
		return "SetSystemRole";
	}

	@RequestMapping(value = "/setRole", method = RequestMethod.GET)
	public String setRoleGet(Model model) {
		// model.addAttribute("role", new Role());
		List<Systems> systemList = getSystemDetail();
		model.addAttribute("systemList", systemList);
		return "SetSystemRole";
	}

	@RequestMapping(value = "/setRole", method = RequestMethod.POST)
	public String addRolePost(HttpServletRequest request, Model model) {
		apiPath = "setRoleInfo";
		url = localURL + domainPath + apiPath;
		String httpResponseJson = null;
		httpclient = new DefaultHttpClient();
		post = new HttpPost(url);
		json = new JSONObject();
		try {
			json.put("systemId", request.getParameter("systemId"));
			json.put("workGrpNo", Long.parseLong(request.getParameter("number")));
			json.put("workGrpName", request.getParameter("name"));
			json.put("description", request.getParameter("description"));
			int isUse = Integer.parseInt(request.getParameter("isUse"));
			if (isUse == 0) {
				json.put("useYn", false);
			} else {
				json.put("useYn", true);
			}
			stringEntityinput = new StringEntity(json.toString());
			stringEntityinput.setContentType("application/json");
			post.addHeader("Accept", "application/json");
			post.addHeader("Content-Type", "application/json");
			post.addHeader("accessToken", "client");
			post.addHeader("clientId", "test");
			post.addHeader("clientSecret", "secret");
			post.setEntity(stringEntityinput);
			httpResponse = httpclient.execute(post);
			httpResponseJson = EntityUtils.toString(httpResponse.getEntity());
			System.out.println(httpResponseJson);
		} catch (Exception e) {
			System.out.println(e);
		}
		return "redirect:ViewRole";
	}

	@RequestMapping(value = "/assignResource", method = RequestMethod.GET)
	public String addResourceGet(Model model) {
		// model.addAttribute("resource", new Resource());
		List<Systems> systemList = getSystemDetail();
		model.addAttribute("systemList", systemList);
		return "AssignResource";
	}

	@RequestMapping(value = "/assignResource", method = RequestMethod.POST)
	public String addResourcePost(HttpServletRequest request, Model model) {
		apiPath = "setResourceInfo";
		url = localURL + domainPath + apiPath;
		String httpResponseJson = null;
		httpclient = new DefaultHttpClient();
		post = new HttpPost(url);
		json = new JSONObject();
		try {
			json.put("systemId", request.getParameter("systemId"));
			json.put("resourcePath", request.getParameter("path"));
			json.put("resourceDesc", request.getParameter("description"));
			int isUse = Integer.parseInt(request.getParameter("isUse"));
			if (isUse == 0) {
				json.put("useYn", false);
			} else {
				json.put("useYn", true);
			}
			stringEntityinput = new StringEntity(json.toString());
			stringEntityinput.setContentType("application/json");
			post.addHeader("Accept", "application/json");
			post.addHeader("Content-Type", "application/json");
			post.addHeader("accessToken", "client");
			post.addHeader("clientId", "test");
			post.addHeader("clientSecret", "secret");
			post.setEntity(stringEntityinput);
			httpResponse = httpclient.execute(post);
			httpResponseJson = EntityUtils.toString(httpResponse.getEntity());
			System.out.println(httpResponseJson);
		} catch (Exception e) {
			System.out.println(e);
		}
		return "Dashboard";
	}

	// View Part
	// View Part
	@RequestMapping(value = "/viewSystem", method = RequestMethod.GET)
	public String viewSystemGet(Model model) {
		// System userSystemRole = null;
		// List<SystemRoleResponse> userSystemRoleList = new ArrayList<>();
		List<Systems> systemList = getSystemDetail();
		model.addAttribute("systemList", systemList);
		return "ViewSystem";
	}

	@RequestMapping(value = "/viewRole", method = RequestMethod.GET)
	public String viewRoleGet(Model model) {
		SystemRoleResponse userSystemRole = null;
		List<SystemRoleResponse> userSystemRoleList = new ArrayList<>();
		apiPath = "getAllSystemRole";
		url = localURL + domainPath + apiPath;
		httpclient = new DefaultHttpClient();
		post = new HttpPost(url);
		json = new JSONObject();
		stringEntityinput = null;
		httpResponse = null;
		try {
			post.addHeader("Accept", "application/json");
			post.addHeader("Content-Type", "application/json");
			post.addHeader("accessToken", "client");
			post.addHeader("clientId", "test");
			post.addHeader("clientSecret", "secret");
			HttpResponse httpResponse = httpclient.execute(post);
			System.out.println("Response Code : " + httpResponse.getStatusLine().getStatusCode());
			json_string = EntityUtils.toString(httpResponse.getEntity());
			System.out.println(json_string);
			JSONObject obj = new JSONObject(json_string);
			JsonElement newJson = new com.google.gson.JsonParser().parse(obj.get("details").toString());
			JsonArray array = newJson.getAsJsonArray();
			Iterator<JsonElement> iterator = array.iterator();
			while (iterator.hasNext()) {
				JsonElement json2 = (JsonElement) iterator.next();
				Gson gson = new Gson();
				userSystemRole = gson.fromJson(json2, SystemRoleResponse.class);
				userSystemRoleList.add(userSystemRole);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		model.addAttribute("userSystemRoleList", userSystemRoleList);
		return "ViewRole";
	}

	@RequestMapping(value = "/viewResource", method = RequestMethod.GET)
	public String viewAssignResource(Model model) {
		List<SystemResource> resourceList = getAssignedResourceDetail();
		model.addAttribute("resourceList", resourceList);
		return "ViewResource";
	}

	@RequestMapping(value = "/viewUser", method = RequestMethod.GET)
	public String viewUserGet(HttpServletRequest request, Model model, RedirectAttributes attributes) {
		UserSystemRole userSystemRole = null;
		List<UserSystemRole> userSystemRoleList = new ArrayList<>();
		apiPath = "getAllUserInfo";
		url = localURL + domainPath + apiPath;
		httpclient = new DefaultHttpClient();
		post = new HttpPost(url);
		json = new JSONObject();
		stringEntityinput = null;
		httpResponse = null;
		HttpSession session;
		try {
			// SessionDetail sessionDetail = new SessionDetail();
			// session = (HttpSession) request.getAttribute("accesssToken");
			session = request.getSession(false);
			post.addHeader("Authorization", "Bearer " + (String) session.getAttribute("accessToken") + "");
			post.addHeader("Accept", "application/json");
			post.addHeader("Content-Type", "application/json");
			post.addHeader("accessToken", (String) request.getAttribute("accessToken"));
			HttpResponse httpResponse = httpclient.execute(post);
			System.out.println("Response Code : " + httpResponse.getStatusLine().getStatusCode());
			json_string = EntityUtils.toString(httpResponse.getEntity());
			JSONObject obj = new JSONObject(json_string);
			System.out.println(json_string);
			JsonElement newJson = new com.google.gson.JsonParser().parse(obj.get("details").toString());
			JsonArray array = newJson.getAsJsonArray();
			Iterator<JsonElement> iterator = array.iterator();
			while (iterator.hasNext()) {
				JsonElement json2 = (JsonElement) iterator.next();
				Gson gson = new Gson();
				userSystemRole = gson.fromJson(json2, UserSystemRole.class);
				userSystemRoleList.add(userSystemRole);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		model.addAttribute("userSystemRoleList", userSystemRoleList);
		return "viewuser";
	}

	@RequestMapping(value = "/getUserResource")
	@ResponseBody
	public String getUserResource(@RequestBody String json, Model model) {
		List<Resource> resourceList = new ArrayList<>();
		GetInfoMinimulRequest requestObj = null;
		String jsonValue = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			GetInfoMinimulRequest requesValue = mapper.readValue(json, GetInfoMinimulRequest.class);
			requestObj = new GetInfoMinimulRequest();
			requestObj.setId(requesValue.getId());
			resourceList = getUserResourceDetail(requestObj.getId());
			jsonValue = mapper.writeValueAsString(resourceList);
		} catch (Exception e) {
			// TODO: handle exception
		}
		System.out.println("Resource detail JSON:" + jsonValue);
		return jsonValue;
	}

	@RequestMapping(value = "/setUserResource", method = RequestMethod.POST)
	public String setUserResource(HttpServletRequest request, Model model, RedirectAttributes attributes) {
		apiPath = "setUserResource";
		url = localURL + domainPath + apiPath;
		String httpResponseJson = null;
		httpclient = new DefaultHttpClient();
		post = new HttpPost(url);
		json = new JSONObject();
		CommonResponse responseModel;
		try {
			json.put("systemResourceId", request.getParameterValues("systemResourceId[]"));
			json.put("userSystemRoleId", request.getParameter("userSysId"));
			stringEntityinput = new StringEntity(json.toString());
			stringEntityinput.setContentType("application/json");
			post.addHeader("Accept", "application/json");
			post.addHeader("Content-Type", "application/json");
			post.addHeader("accessToken", "client");
			post.addHeader("clientId", "test");
			post.addHeader("clientSecret", "secret");
			post.setEntity(stringEntityinput);
			httpResponse = httpclient.execute(post);
			httpResponseJson = EntityUtils.toString(httpResponse.getEntity());
			responseModel = new ObjectMapper().readValue(httpResponseJson, CommonResponse.class);
			System.out.println(responseModel);

		} catch (Exception e) {
			System.out.println(e);
			return "redirect:viewUser";
		}
		if (responseModel.isSuccess()) {
			attributes.addFlashAttribute("successMsg", responseModel.getMessage());
			return "redirect:viewUser";
		} else {
			attributes.addFlashAttribute("errorMsg", responseModel.getMessage());
			return "redirect:viewUser";
		}
	}

	@RequestMapping(value = "/setRoleResource", method = RequestMethod.POST)
	public String setRoleResource(HttpServletRequest request, Model model, RedirectAttributes attributes) {
		apiPath = "setRoleResource";
		url = localURL + domainPath + apiPath;
		String httpResponseJson = null;
		httpclient = new DefaultHttpClient();
		post = new HttpPost(url);
		json = new JSONObject();
		CommonResponse responseModel;
		try {
			System.out.println(request.getParameter("systemRoleId"));
			json.put("systemResourceId", request.getParameterValues("systemResourceId[]"));
			json.put("userSystemRoleId", request.getParameter("systemRoleId"));
			stringEntityinput = new StringEntity(json.toString());
			stringEntityinput.setContentType("application/json");
			post.addHeader("Accept", "application/json");
			post.addHeader("Content-Type", "application/json");
			post.addHeader("accessToken", "client");
			post.addHeader("clientId", "test");
			post.addHeader("clientSecret", "secret");
			post.setEntity(stringEntityinput);
			httpResponse = httpclient.execute(post);
			httpResponseJson = EntityUtils.toString(httpResponse.getEntity());
			responseModel = new ObjectMapper().readValue(httpResponseJson, CommonResponse.class);
			System.out.println(responseModel);

		} catch (Exception e) {
			System.out.println(e);
			return "redirect:viewRole";
		}
		if (responseModel.isSuccess()) {
			attributes.addFlashAttribute("successMsg", responseModel.getMessage());
			return "redirect:viewRole";
		} else {
			attributes.addFlashAttribute("errorMsg", responseModel.getMessage());
			return "redirect:viewRole";
		}
	}

	@RequestMapping(value = "/getRoleResource")
	@ResponseBody
	public String getRoleResource(@RequestBody String json, Model model) {
		List<SystemResource> resourceList = new ArrayList<>();
		GetInfoMinimulRequest requestObj = null;
		String jsonValue = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			GetInfoMinimulRequest requesValue = mapper.readValue(json, GetInfoMinimulRequest.class);
			requestObj = new GetInfoMinimulRequest();
			requestObj.setId(requesValue.getId());
			resourceList = getRoleResourceDetail(requestObj.getId());
			jsonValue = mapper.writeValueAsString(resourceList);
		} catch (Exception e) {
			// TODO: handle exception
		}
		System.out.println("Resource detail JSON:" + jsonValue);
		return jsonValue;
	}

	@RequestMapping(value = "/getSystemResource")
	@ResponseBody
	public String getSystemResource(@RequestBody String json, Model model) {
		List<SystemResource> resourceList = new ArrayList<>();
		GetInfoMinimulRequest requestObj = null;
		String jsonValue = null;
		try {
			ObjectMapper mapper = new ObjectMapper();
			GetInfoMinimulRequest requesValue = mapper.readValue(json, GetInfoMinimulRequest.class);
			requestObj = new GetInfoMinimulRequest();
			requestObj.setId(requesValue.getId());
			resourceList = getSystemResourceDetail(requestObj.getId());
			jsonValue = mapper.writeValueAsString(resourceList);
		} catch (Exception e) {
			// TODO: handle exception
		}
		System.out.println("Resource detail JSON:" + jsonValue);
		return jsonValue;
	}

	public HttpPost getHttpPostInfo(String url, JSONObject json) {
		post = new HttpPost(url);
		try {
			stringEntityinput = new StringEntity(json.toString());
			stringEntityinput.setContentType("application/json");
			post.setHeader("Accept", "application/json");
			post.setHeader("Content-Type", "application/json");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return post;
	}

	public HttpPost getHttpPostInfo(String url, JSONObject json, boolean accessToken) {
		post = new HttpPost(url);
		try {
			stringEntityinput = new StringEntity(json.toString());
			stringEntityinput.setContentType("application/json");
			post.addHeader("Accept", "application/json");
			post.addHeader("Content-Type", "application/json");
			post.addHeader("accessToken", "client");
			post.addHeader("clientId", "test");
			post.addHeader("clientSecret", "secret");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return post;
	}

	// Get Role detail

	public List<SystemRoleResponse> getSystemRoleDetail() {
		apiPath = "getAllSystemRole";
		url = localURL + domainPath + apiPath;
		httpclient = new DefaultHttpClient();
		post = new HttpPost(url);
		json = new JSONObject();
		stringEntityinput = null;
		httpResponse = null;
		List<SystemRoleResponse> systemRoleList = new ArrayList<>();
		SystemRoleResponse systemData = null;
		try {
			stringEntityinput = new StringEntity(json.toString());
			stringEntityinput.setContentType("application/json");
			post.addHeader("Accept", "application/json");
			post.addHeader("Content-Type", "application/json");
			post.addHeader("accessToken", "client");
			post.addHeader("clientId", "test");
			post.addHeader("clientSecret", "secret");
			post.setEntity(stringEntityinput);
			httpResponse = httpclient.execute(post);
			// HttpResponse httpResponse = httpclient.execute(post);
			/*
			 * System.out.println("Response Code : " +
			 * httpResponse.getStatusLine().getStatusCode());
			 */
			json_string = EntityUtils.toString(httpResponse.getEntity());
			JSONObject obj = new JSONObject(json_string);
			JsonElement newJson = new com.google.gson.JsonParser().parse(obj.get("details").toString());
			JsonArray array = newJson.getAsJsonArray();
			Iterator<JsonElement> iterator = array.iterator();
			while (iterator.hasNext()) {
				JsonElement json2 = (JsonElement) iterator.next();
				Gson gson = new Gson();
				systemData = gson.fromJson(json2, SystemRoleResponse.class);
				systemRoleList.add(systemData);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return systemRoleList;
	}

	public List<Systems> getSystemDetail() {
		apiPath = "getAllSystem";
		url = localURL + domainPath + apiPath;
		httpclient = new DefaultHttpClient();
		post = new HttpPost(url);
		json = new JSONObject();
		stringEntityinput = null;
		httpResponse = null;
		List<Systems> systemList = new ArrayList<>();
		Systems systemData = null;
		try {
			post.addHeader("Accept", "application/json");
			post.addHeader("Content-Type", "application/json");
			post.addHeader("accessToken", "client");
			post.addHeader("clientId", "test");
			post.addHeader("clientSecret", "secret");
			HttpResponse httpResponse = httpclient.execute(post);
			System.out.println("Response Code : " + httpResponse.getStatusLine().getStatusCode());
			json_string = EntityUtils.toString(httpResponse.getEntity());
			JSONObject obj = new JSONObject(json_string);
			JsonElement newJson = new com.google.gson.JsonParser().parse(obj.get("details").toString());
			JsonArray array = newJson.getAsJsonArray();
			Iterator<JsonElement> iterator = array.iterator();
			while (iterator.hasNext()) {
				JsonElement json2 = (JsonElement) iterator.next();
				Gson gson = new Gson();
				systemData = gson.fromJson(json2, Systems.class);
				systemList.add(systemData);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return systemList;
	}

	public List<Resource> getUserResourceDetail(String usrSysId) {
		apiPath = "getUserResourceUAS";
		url = localURL + domainPath + apiPath;
		httpclient = new DefaultHttpClient();
		post = new HttpPost(url);
		json = new JSONObject();
		stringEntityinput = null;
		httpResponse = null;
		List<Resource> systemList = new ArrayList<>();
		Resource systemData = null;
		try {
			json.put("id", usrSysId);
			stringEntityinput = new StringEntity(json.toString());
			stringEntityinput.setContentType("application/json");
			post.setHeader("Accept", "application/json");
			post.setHeader("Content-Type", "application/json");
			post.setEntity(stringEntityinput);
			HttpResponse httpResponse = httpclient.execute(post);
			System.out.println("Response Code : " + httpResponse.getStatusLine().getStatusCode());
			json_string = EntityUtils.toString(httpResponse.getEntity());
			System.out.println("Resource Json String:" + json_string);

			JSONObject obj = new JSONObject(json_string);
			JsonElement newJson = new com.google.gson.JsonParser().parse(obj.get("details").toString());
			JsonArray array = newJson.getAsJsonArray();
			Iterator<JsonElement> iterator = array.iterator();
			while (iterator.hasNext()) {
				JsonElement json2 = (JsonElement) iterator.next();
				Gson gson = new Gson();
				systemData = gson.fromJson(json2, Resource.class);
				systemList.add(systemData);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return systemList;
	}

	public List<SystemResource> getRoleResourceDetail(String sysRoleId) {
		apiPath = "getRoleResourceUAS";
		url = localURL + domainPath + apiPath;
		httpclient = new DefaultHttpClient();
		post = new HttpPost(url);
		json = new JSONObject();
		stringEntityinput = null;
		httpResponse = null;
		List<SystemResource> systemList = new ArrayList<>();
		SystemResource systemData = null;
		try {
			json.put("id", sysRoleId);
			stringEntityinput = new StringEntity(json.toString());
			stringEntityinput.setContentType("application/json");
			post.setHeader("Accept", "application/json");
			post.setHeader("Content-Type", "application/json");
			post.setEntity(stringEntityinput);
			HttpResponse httpResponse = httpclient.execute(post);
			System.out.println("Response Code : " + httpResponse.getStatusLine().getStatusCode());
			json_string = EntityUtils.toString(httpResponse.getEntity());
			System.out.println("Role Resource Json String:" + json_string);
			JSONObject obj = new JSONObject(json_string);
			JsonElement newJson = new com.google.gson.JsonParser().parse(obj.get("details").toString());
			JsonArray array = newJson.getAsJsonArray();
			Iterator<JsonElement> iterator = array.iterator();
			while (iterator.hasNext()) {
				JsonElement json2 = (JsonElement) iterator.next();
				Gson gson = new Gson();
				systemData = gson.fromJson(json2, SystemResource.class);
				systemList.add(systemData);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return systemList;
	}

	public List<SystemResource> getAssignedResourceDetail() {
		apiPath = "getAllResource";
		url = localURL + domainPath + apiPath;
		httpclient = new DefaultHttpClient();
		post = new HttpPost(url);
		json = new JSONObject();
		stringEntityinput = null;
		httpResponse = null;
		List<SystemResource> systemList = new ArrayList<>();
		SystemResource systemData = null;
		try {
			post.addHeader("Accept", "application/json");
			post.addHeader("Content-Type", "application/json");
			post.addHeader("accessToken", "client");
			post.addHeader("clientId", "test");
			post.addHeader("clientSecret", "secret");
			HttpResponse httpResponse = httpclient.execute(post);
			System.out.println("Response Code : " + httpResponse.getStatusLine().getStatusCode());
			json_string = EntityUtils.toString(httpResponse.getEntity());
			System.out.println("Resource Json String:" + json_string);
			JSONObject obj = new JSONObject(json_string);
			JsonElement newJson = new com.google.gson.JsonParser().parse(obj.get("details").toString());
			JsonArray array = newJson.getAsJsonArray();
			Iterator<JsonElement> iterator = array.iterator();
			while (iterator.hasNext()) {
				JsonElement json2 = (JsonElement) iterator.next();
				Gson gson = new Gson();
				systemData = gson.fromJson(json2, SystemResource.class);
				systemList.add(systemData);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return systemList;
	}

	private List<SystemResource> getSystemResourceDetail(String sysId) {
		apiPath = "getSystemResource";
		url = localURL + domainPath + apiPath;
		httpclient = new DefaultHttpClient();
		post = new HttpPost(url);
		json = new JSONObject();
		stringEntityinput = null;
		httpResponse = null;
		List<SystemResource> systemList = new ArrayList<>();
		SystemResource systemData = null;
		try {
			json.put("id", sysId);
			stringEntityinput = new StringEntity(json.toString());
			stringEntityinput.setContentType("application/json");
			post.setHeader("Accept", "application/json");
			post.setHeader("Content-Type", "application/json");
			post.setEntity(stringEntityinput);
			HttpResponse httpResponse = httpclient.execute(post);
			System.out.println("Response Code : " + httpResponse.getStatusLine().getStatusCode());
			json_string = EntityUtils.toString(httpResponse.getEntity());
			System.out.println("System Resource Json String:" + json_string);
			JSONObject obj = new JSONObject(json_string);
			JsonElement newJson = new com.google.gson.JsonParser().parse(obj.get("details").toString());
			JsonArray array = newJson.getAsJsonArray();
			Iterator<JsonElement> iterator = array.iterator();
			while (iterator.hasNext()) {
				JsonElement json2 = (JsonElement) iterator.next();
				Gson gson = new Gson();
				systemData = gson.fromJson(json2, SystemResource.class);
				systemList.add(systemData);
			}
		} catch (Exception e) {
			System.out.println(e);
		}
		return systemList;
	}
}
