package com.elanduas.reqrespmodel;

public class RoleSystemsRequest {

	private String id;
}
