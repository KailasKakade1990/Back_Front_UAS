package com.elanduas.reqrespmodel;

public class UserInfoRequest {

}
