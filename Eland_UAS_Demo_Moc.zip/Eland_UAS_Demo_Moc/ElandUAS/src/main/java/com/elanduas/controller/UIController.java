package com.elanduas.controller;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;
import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.ui.Model;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.elanduas.model.LoginRequest;
import com.elanduas.model.Resource;
import com.elanduas.model.Role;
import com.elanduas.model.SetResource;
import com.elanduas.model.SystemResource;
import com.elanduas.model.Systems;
import com.elanduas.model.User;
import com.elanduas.model.UserSystemRole;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;


public class UIController {

	
	String userKey = "userLoginresponse";
	private static final String localURL = "http://localhost:8081/";
	//private static final String localURL = "http://13.209.161.153:8081/";
	private static final String domainPath = "uas/";
	String apiPath = null;
	String url = null;
	HttpClient httpclient;
	HttpPost post;
	HttpResponse httpResponse;	
	JSONObject json;
	StringEntity stringEntityinput = null;
	JSONArray jsonArray;
	String json_string;
	
	 @RequestMapping(value = "/", method = RequestMethod.GET)
	 public String login(Model model) {
		 
		 //pre login check
		 apiPath = "checkSsoValidation";
		 url = localURL+domainPath+apiPath;
		 String  httpResponseJson = null;
		 httpclient = new DefaultHttpClient();
		 post = new HttpPost(url);
		 json = new JSONObject();
		 stringEntityinput = null;
		 httpResponse = null;
		 
		 LoginRequest loginRequest = new LoginRequest();
		 model.addAttribute("loginForm", loginRequest);
		 return "login";
	 }
	 
	 @RequestMapping(value = "/login", method = RequestMethod.POST)
	 public String loginPost(HttpServletRequest request, @ModelAttribute("login") @Validated LoginRequest login, Model model) {
		 		
		 apiPath = "login";
		 return "Dashboard";
	 }
	 
	 @RequestMapping(value = "/addUser", method = RequestMethod.GET)
	 public String addUserGet(Model model) {
		 List<Systems> systemList = getSystemDetail();
		 List<Role> roleList = getRoleDetail();
		 model.addAttribute("systemList",systemList);
		 model.addAttribute("roleList", roleList);
		 model.addAttribute("user", new User());
		 return "adduser";
	 }
	 
	 @RequestMapping(value = "/viewUser", method = RequestMethod.GET)
	 public String viewUserGet(Model model) {
		 UserSystemRole userSystemRole = null;
		 List<UserSystemRole> userSystemRoleList = new ArrayList<>();
		 apiPath = "user";
		 url = localURL+domainPath+apiPath;
		 httpclient = new DefaultHttpClient();	
		 HttpGet post = new HttpGet(url);
		 json = new JSONObject();
		 stringEntityinput = null;
		 httpResponse = null;
		 try {
			post.setHeader("Accept", "application/json");
			post.setHeader("Content-Type", "application/json");
			HttpResponse httpResponse = httpclient.execute(post);
			System.out.println("Response Code : " 
	                + httpResponse.getStatusLine().getStatusCode());
			json_string = EntityUtils.toString(httpResponse.getEntity());
			JsonElement newJson = new com.google.gson.JsonParser()
					.parse(json_string);
			JsonArray array = newJson.getAsJsonArray();
			Iterator<JsonElement> iterator = array.iterator();
			 while (iterator.hasNext()) {
		           	JsonElement json2 = (JsonElement) iterator.next();
		         	Gson gson = new Gson();
		         	userSystemRole = gson.fromJson(json2, UserSystemRole.class);
		         	userSystemRoleList.add(userSystemRole);
		         }
		 }catch(Exception e) {
			 System.out.println(e);
		 }
		 model.addAttribute("userSystemRoleList", userSystemRoleList);
		 return "viewuser";
	 }
	 
	 @RequestMapping(value = "/addUser", method = RequestMethod.POST)
	 public String addUserPost(HttpServletRequest request, Model model) {
		 
		 apiPath = "user";
		 url = localURL+domainPath+apiPath;
		 String  httpResponseJson = null;
		 httpclient = new DefaultHttpClient();
		 post = new HttpPost(url);
		 json = new JSONObject();
		 try {
				json.put("accountNo", Long.parseLong(request.getParameter("accountNo")));
				json.put("userLogId", request.getParameter("userLogId"));
				json.put("userName", request.getParameter("userName"));
				json.put("password", request.getParameter("password"));
				json.put("isUse", Long.parseLong(request.getParameter("isUse")));
				json.put("email", request.getParameter("email"));
				json.put("applyStartDate", "2019-02-17T17:16:02.776Z");
				json.put("applyEndDate", "2019-02-17T17:16:02.776Z");
				json.put("telephone_No", Long.parseLong(request.getParameter("telephone_No")));
				json.put("mobile", Long.parseLong(request.getParameter("mobile")));
				json.put("system_id",request.getParameterValues("systemId"));
				json.put("role_id",request.getParameterValues("roleId"));
				
				stringEntityinput = new StringEntity(json.toString());
				stringEntityinput.setContentType("application/json");
				post.setHeader("Accept", "application/json");
				post.setHeader("Content-Type", "application/json");
				post.setEntity(stringEntityinput);
				httpResponse = httpclient.execute(post);
				httpResponseJson = EntityUtils.toString(httpResponse.getEntity());
				System.out.println(httpResponseJson);
		 }catch(Exception e)
		 {
			 System.out.println(e);
		 }
		 return "Dashboard";
	 }
	 
	 @RequestMapping(value = "/addSystem", method = RequestMethod.GET)
	 public String addSystemGet(Model model) {
		 model.addAttribute("system", new Systems());
		 return "AddSystem";
	 }
	 
	 @RequestMapping(value = "/addSystem", method = RequestMethod.POST)
	 public String addSystemPost(HttpServletRequest request, @ModelAttribute("system") Systems system, Model model) {
		 apiPath = "addSystem";
		 url = localURL+domainPath+apiPath;
		 String  httpResponseJson = null;
		 httpclient = new DefaultHttpClient();
		 post = new HttpPost(url);
		 json = new JSONObject();
		 try {
				json.put("name", system.getName());
				json.put("description", system.getDescription());
				json.put("isUse", system.getIsUse());
				json.put("inOtpUse", system.getInOtpUse());
				json.put("clientId", system.getClientId());
				json.put("clientSecret", system.getClientSecret());
				stringEntityinput = new StringEntity(json.toString());
				stringEntityinput.setContentType("application/json");
				post.setHeader("Accept", "application/json");
				post.setHeader("Content-Type", "application/json");
				post.setEntity(stringEntityinput);
				httpResponse = httpclient.execute(post);
				httpResponseJson = EntityUtils.toString(httpResponse.getEntity());
				System.out.println(httpResponseJson);
		 }catch(Exception e)
		 {
			 System.out.println(e);
		 }
		 return "Dashboard";
	 }
	 
	 @RequestMapping(value = "/viewSystem", method = RequestMethod.GET)
	 public String viewSystemGet(HttpServletRequest request, Model model) {
		 apiPath = "system";
		 url = localURL+domainPath+apiPath;
		 httpclient = new DefaultHttpClient();	
		 HttpGet post = new HttpGet(url);
		 json = new JSONObject();
		 stringEntityinput = null;
		 httpResponse = null;
		 List<Systems> systemList= new ArrayList<>();
		 Systems systemData = null;
		 try {
			post.setHeader("Accept", "application/json");
			post.setHeader("Content-Type", "application/json");
			HttpResponse httpResponse = httpclient.execute(post);
			System.out.println("Response Code : " 
	                + httpResponse.getStatusLine().getStatusCode());
			json_string = EntityUtils.toString(httpResponse.getEntity());
			JsonElement newJson = new com.google.gson.JsonParser()
					.parse(json_string);
			JsonArray array = newJson.getAsJsonArray();
			Iterator<JsonElement> iterator = array.iterator();
			 while (iterator.hasNext()) {
		           	JsonElement json2 = (JsonElement) iterator.next();
		         	Gson gson = new Gson();
		         	systemData = gson.fromJson(json2, Systems.class);
		         	systemList.add(systemData);
		         }
		 }catch(Exception e) {
			 System.out.println(e);
		 }
		 model.addAttribute("systemList", systemList);
		 return "ViewSystem";
	 }
	 
	 @RequestMapping(value = "/editSystem", method = RequestMethod.POST)
	 public String editSystemPost(@ModelAttribute("system") Systems system, Model model) {
		 apiPath = "system";
		 url = localURL+domainPath+apiPath;
		 String  httpResponseJson = null;
		 httpclient = new DefaultHttpClient();
		 HttpPost post = new HttpPost(url);
		 json = new JSONObject();
		 try {
			 	json.put("systemId", system.getSystemId());
				json.put("name", system.getName());
				json.put("description", system.getDescription());
				json.put("isUse", system.getIsUse());
				json.put("inOtpUse", system.getInOtpUse());
				json.put("clientId", system.getClientId());
				json.put("clientSecret", system.getClientSecret());
				stringEntityinput = new StringEntity(json.toString());
				stringEntityinput.setContentType("application/json");
				post.setHeader("Accept", "application/json");
				post.setHeader("Content-Type", "application/json");
				post.setEntity(stringEntityinput);
				httpResponse = httpclient.execute(post);
				httpResponseJson = EntityUtils.toString(httpResponse.getEntity());
				System.out.println(httpResponseJson);
		 }catch(Exception e)
		 {
			 System.out.println(e);
		 }
		 return "Dashboard";
	 }
	 
	 @RequestMapping(value = "/addRole", method = RequestMethod.GET)
	 public String addRoleGet(Model model) {
		 model.addAttribute("role", new Role());
		 return "AddRole";
	 }
	 
	 @RequestMapping(value = "/viewRole", method = RequestMethod.GET)
	 public String viewRoleGet(Model model) {
		 UserSystemRole userSystemRole = null;
		 List<UserSystemRole> userSystemRoleList = new ArrayList<>();
		 apiPath = "getAssignedRole";
		 url = localURL+domainPath+apiPath;
		 httpclient = new DefaultHttpClient();	
		 HttpGet post = new HttpGet(url);
		 json = new JSONObject();
		 stringEntityinput = null;
		 httpResponse = null;
		 try {
			post.setHeader("Accept", "application/json");
			post.setHeader("Content-Type", "application/json");
			HttpResponse httpResponse = httpclient.execute(post);
			System.out.println("Response Code : " 
	                + httpResponse.getStatusLine().getStatusCode());
			json_string = EntityUtils.toString(httpResponse.getEntity());
			JsonElement newJson = new com.google.gson.JsonParser()
					.parse(json_string);
			JsonArray array = newJson.getAsJsonArray();
			Iterator<JsonElement> iterator = array.iterator();
			 while (iterator.hasNext()) {
		           	JsonElement json2 = (JsonElement) iterator.next();
		         	Gson gson = new Gson();
		         	userSystemRole = gson.fromJson(json2, UserSystemRole.class);
		         	userSystemRoleList.add(userSystemRole);
		         }
		 }catch(Exception e) {
			 System.out.println(e);
		 }
		 model.addAttribute("userSystemRoleList", userSystemRoleList);
		 return "ViewRole";
	 }
	 
	 @RequestMapping(value = "/addRole", method = RequestMethod.POST)
	 public String addRolePost(HttpServletRequest request, @ModelAttribute("role") Role role, Model model) {
		 apiPath = "role";
		 url = localURL+domainPath+apiPath;
		 String  httpResponseJson = null;
		 httpclient = new DefaultHttpClient();
		 post = new HttpPost(url);
		 json = new JSONObject();
		 try {
				json.put("name", role.getName());
				json.put("description", role.getDescription());
				json.put("number", role.getNumber());
				json.put("isUse", role.getIsUse());
				stringEntityinput = new StringEntity(json.toString());
				stringEntityinput.setContentType("application/json");
				post.setHeader("Accept", "application/json");
				post.setHeader("Content-Type", "application/json");
				post.setEntity(stringEntityinput);
				httpResponse = httpclient.execute(post);
				httpResponseJson = EntityUtils.toString(httpResponse.getEntity());
				System.out.println(httpResponseJson);
		 }catch(Exception e)
		 {
			 System.out.println(e);
		 }
		 return "Dashboard";
	 }
	 
	 @RequestMapping(value = "/addResource", method = RequestMethod.GET)
	 public String addResourceGet(Model model) {
		 model.addAttribute("resource", new Resource());
		 return "addResource";
	 }
	 
	 @RequestMapping(value = "/addResource", method = RequestMethod.POST)
	 public String addResourcePost(HttpServletRequest request,@ModelAttribute("resource") Resource resource, Model model) {
		 apiPath = "resource";
		 url = localURL+domainPath+apiPath;
		 String  httpResponseJson = null;
		 httpclient = new DefaultHttpClient();
		 post = new HttpPost(url);
		 json = new JSONObject();
		 try {
				json.put("path", resource.getPath());
				json.put("description", resource.getDescription());
				json.put("isUse", resource.getIsUse());
				stringEntityinput = new StringEntity(json.toString());
				stringEntityinput.setContentType("application/json");
				post.setHeader("Accept", "application/json");
				post.setHeader("Content-Type", "application/json");
				post.setEntity(stringEntityinput);
				httpResponse = httpclient.execute(post);
				httpResponseJson = EntityUtils.toString(httpResponse.getEntity());
				System.out.println(httpResponseJson);
		 }catch(Exception e)
		 {
			 System.out.println(e);
		 }
		 return "Dashboard";
	 }
	 
	 @RequestMapping(value = "/viewResource", method = RequestMethod.GET)
	 public String viewAssignResource(Model model) {
		 List<SystemResource> resourceList = getAssignedResourceDetail();
		 model.addAttribute("resourceList",resourceList);
		 return "ViewResource";
	 }
	 
	 @RequestMapping(value = "/assignResource", method = RequestMethod.GET)
	 public String assignResource(Model model) {
		 List<Systems> systemList = getSystemDetail();
		 List<Resource> resourceList = getResourceDetail();
		 System.out.println(resourceList.get(0));
		 model.addAttribute("systemList", systemList);
		 model.addAttribute("resourceList",resourceList);
		 return "AssignResource";
	 }
	 
	 @RequestMapping(value = "/assignResource", method = RequestMethod.POST)
	 public String assignResourcePost(HttpServletRequest request,@ModelAttribute("resource") SetResource resource,Model model) {
		 
		 apiPath = "systemResources";
		 url = localURL+domainPath+apiPath;
		 String  httpResponseJson = null;
		 httpclient = new DefaultHttpClient();
		 post = new HttpPost(url);
		 json = new JSONObject();
		 try {
			 Long isUse;
				json.put("systemId", request.getParameterValues("systemId"));
				json.put("resourceId", request.getParameterValues("resourceId"));
				if(request.getParameter("isUse") == null) {
					isUse = (long) 0;
				} else {
					isUse = Long.parseLong(request.getParameter("isUse"));
				}
				json.put("isUse",isUse);
				stringEntityinput = new StringEntity(json.toString());
				stringEntityinput.setContentType("application/json");
				post.setHeader("Accept", "application/json");
				post.setHeader("Content-Type", "application/json");
				post.setEntity(stringEntityinput);
				httpResponse = httpclient.execute(post);
				httpResponseJson = EntityUtils.toString(httpResponse.getEntity());
				System.out.println(httpResponseJson);
		 }catch(Exception e)
		 {
			 System.out.println(e);
		 }
		 return "Dashboard";
	 }
	 
	 
	 // Get Role detail
	 
	 public List<Role> getRoleDetail() {
		 apiPath = "role";
		 url = localURL+domainPath+apiPath;
		 httpclient = new DefaultHttpClient();	
		 HttpGet post = new HttpGet(url);
		 json = new JSONObject();
		 stringEntityinput = null;
		 httpResponse = null;
		 List<Role> roleList= new ArrayList<>();
		 Role role = null;
		 try {
			post.setHeader("Accept", "application/json");
			post.setHeader("Content-Type", "application/json");
			HttpResponse httpResponse = httpclient.execute(post);
			System.out.println("Response Code : " 
	                + httpResponse.getStatusLine().getStatusCode());
			json_string = EntityUtils.toString(httpResponse.getEntity());
			JsonElement newJson = new com.google.gson.JsonParser()
					.parse(json_string);
			JsonArray array = newJson.getAsJsonArray();
			Iterator<JsonElement> iterator = array.iterator();
			 while (iterator.hasNext()) {
		           	JsonElement json2 = (JsonElement) iterator.next();
		         	Gson gson = new Gson();
		         	role = gson.fromJson(json2, Role.class);
		         	roleList.add(role);
		         }
		 }catch(Exception e) {
			 System.out.println(e);
		 }
		 return roleList;
	 }
	 
	 public List<Systems> getSystemDetail() {
		 apiPath = "system";
		 url = localURL+domainPath+apiPath;
		 httpclient = new DefaultHttpClient();	
		 HttpGet post = new HttpGet(url);
		 json = new JSONObject();
		 stringEntityinput = null;
		 httpResponse = null;
		 List<Systems> systemList= new ArrayList<>();
		 Systems systemData = null;
		 try {
			post.setHeader("Accept", "application/json");
			post.setHeader("Content-Type", "application/json");
			HttpResponse httpResponse = httpclient.execute(post);
			System.out.println("Response Code : " 
	                + httpResponse.getStatusLine().getStatusCode());
			json_string = EntityUtils.toString(httpResponse.getEntity());
			JsonElement newJson = new com.google.gson.JsonParser()
					.parse(json_string);
			JsonArray array = newJson.getAsJsonArray();
			Iterator<JsonElement> iterator = array.iterator();
			 while (iterator.hasNext()) {
		           	JsonElement json2 = (JsonElement) iterator.next();
		         	Gson gson = new Gson();
		         	systemData = gson.fromJson(json2, Systems.class);
		         	systemList.add(systemData);
		         }
		 }catch(Exception e) {
			 System.out.println(e);
		 }
		 return systemList;
	 }
	 
	 public List<Resource> getResourceDetail() {
		 apiPath = "resource";
		 url = localURL+domainPath+apiPath;
		 httpclient = new DefaultHttpClient();	
		 HttpGet post = new HttpGet(url);
		 json = new JSONObject();
		 stringEntityinput = null;
		 httpResponse = null;
		 List<Resource> systemList= new ArrayList<>();
		 Resource systemData = null;
		 try {
			post.setHeader("Accept", "application/json");
			post.setHeader("Content-Type", "application/json");
			HttpResponse httpResponse = httpclient.execute(post);
			System.out.println("Response Code : " 
	                + httpResponse.getStatusLine().getStatusCode());
			json_string = EntityUtils.toString(httpResponse.getEntity());
			System.out.println("Resource Json String:"+json_string);
			JsonElement newJson = new com.google.gson.JsonParser()
					.parse(json_string);
			JsonArray array = newJson.getAsJsonArray();
			Iterator<JsonElement> iterator = array.iterator();
			 while (iterator.hasNext()) {
		           	JsonElement json2 = (JsonElement) iterator.next();
		         	Gson gson = new Gson();
		         	systemData = gson.fromJson(json2, Resource.class);
		         	systemList.add(systemData);
		         }
		 }catch(Exception e) {
			 System.out.println(e);
		 }
		 return systemList;
	 }
	 
	 public List<SystemResource> getAssignedResourceDetail() {
		 apiPath = "systemResources";
		 url = localURL+domainPath+apiPath;
		 httpclient = new DefaultHttpClient();	
		 HttpGet post = new HttpGet(url);
		 json = new JSONObject();
		 stringEntityinput = null;
		 httpResponse = null;
		 List<SystemResource> systemList= new ArrayList<>();
		 SystemResource systemData = null;
		 try {
			post.setHeader("Accept", "application/json");
			post.setHeader("Content-Type", "application/json");
			HttpResponse httpResponse = httpclient.execute(post);
			System.out.println("Response Code : " 
	                + httpResponse.getStatusLine().getStatusCode());
			json_string = EntityUtils.toString(httpResponse.getEntity());
			System.out.println("Resource Json String:"+json_string);
			JsonElement newJson = new com.google.gson.JsonParser()
					.parse(json_string);
			JsonArray array = newJson.getAsJsonArray();
			Iterator<JsonElement> iterator = array.iterator();
			 while (iterator.hasNext()) {
		           	JsonElement json2 = (JsonElement) iterator.next();
		         	Gson gson = new Gson();
		         	systemData = gson.fromJson(json2, SystemResource.class);
		         	systemList.add(systemData);
		         }
		 }catch(Exception e) {
			 System.out.println(e);
		 }
		 return systemList;
	 }
}
