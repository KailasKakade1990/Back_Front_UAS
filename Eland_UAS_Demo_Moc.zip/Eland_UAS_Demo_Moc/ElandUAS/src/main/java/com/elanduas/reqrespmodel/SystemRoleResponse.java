package com.elanduas.reqrespmodel;

import com.elanduas.model.Role;
import com.elanduas.model.Systems;

public class SystemRoleResponse {

	private Long systemRoleId;
	private Systems system;
	private Role role;
	private String description;
	private Long is_use;
	private Long userCount;
	private Long roleCount;
	public Long getSystemRoleId() {
		return systemRoleId;
	}
	public void setSystemRoleId(Long systemRoleId) {
		this.systemRoleId = systemRoleId;
	}
	public Systems getSystem() {
		return system;
	}
	public void setSystem(Systems system) {
		this.system = system;
	}
	public Role getRole() {
		return role;
	}
	public void setRole(Role role) {
		this.role = role;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}

	public Long getIs_use() {
		return is_use;
	}
	public void setIs_use(Long is_use) {
		this.is_use = is_use;
	}
	public Long getUserCount() {
		return userCount;
	}
	public void setUserCount(Long userCount) {
		this.userCount = userCount;
	}
	public Long getRoleCount() {
		return roleCount;
	}
	public void setRoleCount(Long roleCount) {
		this.roleCount = roleCount;
	}
}
