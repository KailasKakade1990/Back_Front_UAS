package com.elanduas.model;

import java.util.Date;

public class User {

	private Long userId;
	private Long accountNo;
	private String userLogId;
	private String userName;
	private String password;
	private Long telephone_No;
	private Long mobile;
	private String email;
	private Date applyStartDate;
	private Date applyEndDate;
	private Long isUse;
	private String[] roleId;
	private String[] systemId;
	public Long getUserId() {
		return userId;
	}
	public void setUserId(Long userId) {
		this.userId = userId;
	}
	public Long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(Long accountNo) {
		this.accountNo = accountNo;
	}
	public String getUserLogId() {
		return userLogId;
	}
	public void setUserLogId(String userLogId) {
		this.userLogId = userLogId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public Long getTelephone_No() {
		return telephone_No;
	}
	public void setTelephone_No(Long telephone_No) {
		this.telephone_No = telephone_No;
	}
	public Long getMobile() {
		return mobile;
	}
	public void setMobile(Long mobile) {
		this.mobile = mobile;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Date getApplyStartDate() {
		return applyStartDate;
	}
	public void setApplyStartDate(Date applyStartDate) {
		this.applyStartDate = applyStartDate;
	}
	public Date getApplyEndDate() {
		return applyEndDate;
	}
	public void setApplyEndDate(Date applyEndDate) {
		this.applyEndDate = applyEndDate;
	}
	public Long getIsUse() {
		return isUse;
	}
	public void setIsUse(Long isUse) {
		this.isUse = isUse;
	}
	public String[] getRole_id() {
		return roleId;
	}
	public void setRole_id(String[] role_id) {
		this.roleId = role_id;
	}
	public String[] getSystem_id() {
		return systemId;
	}
	public void setSystem_id(String[] system_id) {
		this.systemId = system_id;
	}
}
