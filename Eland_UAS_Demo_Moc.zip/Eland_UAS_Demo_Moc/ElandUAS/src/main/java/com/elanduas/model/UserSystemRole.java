package com.elanduas.model;

public class UserSystemRole {

	private String userSystemRoleId;
	private User user;
	private SystemRole systemRole;
	private Long isUse;
	private Long resourceCount;
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public Long getIsUse() {
		return isUse;
	}
	public void setIsUse(Long isUse) {
		this.isUse = isUse;
	}
	public Long getResourceCount() {
		return resourceCount;
	}
	public void setResourceCount(Long resourceCount) {
		this.resourceCount = resourceCount;
	}
	public SystemRole getSystemRole() {
		return systemRole;
	}
	public void setSystemRole(SystemRole systemRole) {
		this.systemRole = systemRole;
	}
	public String getUserSystemRoleId() {
		return userSystemRoleId;
	}
	public void setUserSystemRoleId(String userSystemRoleId) {
		this.userSystemRoleId = userSystemRoleId;
	}
	
	
}
