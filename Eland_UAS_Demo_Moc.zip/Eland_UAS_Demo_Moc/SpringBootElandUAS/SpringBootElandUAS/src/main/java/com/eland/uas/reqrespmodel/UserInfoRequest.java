package com.eland.uas.reqrespmodel;

public class UserInfoRequest {
	
	private String userId;
	private String userNm;
	private String telNo;
	private String mobileNo;
	private String useApplyStartDate;
	private String useApplyEndDate;
	private String emailAddress;
	private Boolean useYn;

	
	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getTelNo() {
		return telNo;
	}

	public void setTelNo(String telNo) {
		this.telNo = telNo;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getUserNm() {
		return userNm;
	}

	public void setUserNm(String userNm) {
		this.userNm = userNm;
	}
	
	public String getUseApplyStartDate() {
		return useApplyStartDate;
	}

	public void setUseApplyStartDate(String useApplyStartDate) {
		this.useApplyStartDate = useApplyStartDate;
	}

	public String getUseApplyEndDate() {
		return useApplyEndDate;
	}

	public void setUseApplyEndDate(String useApplyEndDate) {
		this.useApplyEndDate = useApplyEndDate;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	/*public Boolean getIsUse() {
		return isUse;
	}

	public void setIsUse(Boolean isUse) {
		this.isUse = isUse;
	}*/

	public Boolean getUseYn() {
		return useYn;
	}

	public void setUseYn(Boolean useYn) {
		this.useYn = useYn;
	}

}
