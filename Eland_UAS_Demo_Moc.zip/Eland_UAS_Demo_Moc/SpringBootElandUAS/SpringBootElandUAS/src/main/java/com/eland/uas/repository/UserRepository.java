package com.eland.uas.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.eland.uas.entity.User;

public interface UserRepository extends CustomUserRespository, JpaRepository<User, Long> {

	User findByUserLogId(String userLogId);
	User findByUserId(Long userId);	
	//List<Long> getAccountNoByUserName(String userName);
}
