package com.eland.uas;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.eland.uas.entity.User;

@Repository
public interface UserRepository1 extends PagingAndSortingRepository<User, Long> {

	User findByUserLogId(String username);

}
