package com.eland.uas.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.eland.uas.entity.Resource;
import com.eland.uas.entity.Role;
import com.eland.uas.entity.SystemsResource;

@Repository
public interface CustomSystemsResourceRepository {

	List<SystemsResource> getResourceBySystemId(String systemId);
	SystemsResource getResourceBySystemId(Long systemId, Long resourceId);
}
