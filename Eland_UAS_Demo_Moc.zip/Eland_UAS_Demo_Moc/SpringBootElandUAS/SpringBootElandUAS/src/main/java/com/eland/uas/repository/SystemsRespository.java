package com.eland.uas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eland.uas.entity.Systems;

public interface SystemsRespository  extends JpaRepository<Systems, Long>, CustomSystemRepository{
}
