package com.eland.uas.controller;
import java.math.BigInteger;
import java.security.Principal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.eland.uas.entity.Otp;
import com.eland.uas.entity.Resource;
import com.eland.uas.entity.Role;
import com.eland.uas.entity.Systems;
import com.eland.uas.entity.SystemsResource;
import com.eland.uas.entity.SystemsRole;
import com.eland.uas.entity.User;
import com.eland.uas.entity.UserSystemsRole;
import com.eland.uas.passwordutil.PasswordUtil;
import com.eland.uas.repository.OtpRepository;
import com.eland.uas.repository.ResourceRepository;
import com.eland.uas.repository.RoleRepository;
import com.eland.uas.repository.RoleSystemResourceRepository;
import com.eland.uas.repository.SystemOtpRepository;
import com.eland.uas.repository.SystemsResourceRepository;
import com.eland.uas.repository.SystemsRespository;
import com.eland.uas.repository.SystemsRoleRepository;
import com.eland.uas.repository.UserRepository;
import com.eland.uas.repository.UserSystemsResourceRepository;
import com.eland.uas.repository.UserSystemsRoleRepository;
import com.eland.uas.reqresp.OtpValidateRequest;
import com.eland.uas.reqrespmodel.CommonGetResponse;
import com.eland.uas.reqrespmodel.CommonResponse;
import com.eland.uas.reqrespmodel.GetUserResourceObj;
import com.eland.uas.reqrespmodel.GetUserResourceObjResponse;
import com.eland.uas.reqrespmodel.GetUserRoleObjResponse;
import com.eland.uas.reqrespmodel.PasswordRequestResp;
import com.eland.uas.reqrespmodel.ResetPasswordRequest;
import com.eland.uas.reqrespmodel.SetResourceObj;
import com.eland.uas.reqrespmodel.SetResourceObjListRequest;
import com.eland.uas.reqrespmodel.SetRoleObj;
import com.eland.uas.reqrespmodel.SetRoleObjListRequest;
import com.eland.uas.reqrespmodel.UserInfoRequest;
import com.eland.uas.reqrespmodel.UserInfoRequestObj;
import com.eland.uas.reqrespmodel.UserInfoResponse;
import com.eland.uas.service.PreLoginUserService;

@RestController
@RequestMapping("/user")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class SourceSystemController {

	private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

	@Autowired
	private ResourceRepository resourceRepository;
	@Autowired
	private RoleRepository roleRepository;
	@Autowired
	private SystemsResourceRepository systemsResourceRepository;
	@Autowired
	private SystemsRespository systemsRepository;
	@Autowired
	private SystemsRoleRepository systemsRoleRepository;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private UserSystemsRoleRepository userSystemsRoleRepository;
	@Autowired
	private UserSystemsResourceRepository userSystemsResourceRepository;
	@Autowired
	private RoleSystemResourceRepository roleSystemsResourceRepository;
	@Autowired
	private PreLoginUserService userService;
	@Autowired
	private SystemOtpRepository systemOtpRepository;
	@Autowired
	private OtpRepository otpRepository;
	HttpHeaders respHeader = new HttpHeaders();

	/*
	 * SOURCE SYSTEM USER API STARTS*	
	 */
	
	
	
	@RequestMapping(value="/putOtpCode", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> checkOtp(@RequestHeader HttpHeaders headers, @RequestBody OtpValidateRequest otpValidateRequest,
			Principal principal) {
		CommonResponse response = new CommonResponse();
		if (principal != null) {
			Otp otp1 = otpRepository.findByOtpAndUserUserId(otpValidateRequest.getOtp(), otpValidateRequest.getUserId());
			if (otp1 != null) {
				response.setSuccess(true);
				response.setMessage("OTP is Valid, Login Sucsess");
				response.setCode("200");
				//response.setAccessToken(headers.get("accessToken").get(1));
				//respHeader.add("accessToken", headers.get("accessToken").get(1));
				return  ResponseEntity.ok().headers(respHeader).body(response);
			} else {
				response.setSuccess(false);
				response.setMessage("OTP is not Valid, Login not Sucsess");
				response.setCode("9999");
				return  ResponseEntity.status(200).headers(respHeader).body(response);
			}

		} else {
			response.setSuccess(false);
			response.setMessage("UnAuthorized Request");
			response.setCode("9999");
			return  ResponseEntity.status(200).headers(respHeader).body(response);
		}
	}
	
	@SuppressWarnings("unused")
	@RequestMapping(value = "/getUserInfo", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")

	public ResponseEntity<?> getLoggedUserInfo(@RequestHeader HttpHeaders headers, Principal principal) {
		
		UserInfoResponse response = new UserInfoResponse();
		if (principal != null) {
			String userId = principal.getName();
			User user = userRepository.findByUserLogId(userId);
			List<User> usrList = new ArrayList<>();
			UserInfoRequest userinfoRequest = new UserInfoRequest();
			userinfoRequest.setUserId(user.getUserLogId());
			userinfoRequest.setUserNm(user.getUserName());
			userinfoRequest.setMobileNo(user.getMobile().toString());
			userinfoRequest.setTelNo(user.getTelephone_No().toString());
			userinfoRequest.setEmailAddress(user.getEmail());
			userinfoRequest.setUseApplyStartDate(user.getApplyStartDate().toString());
			userinfoRequest.setUseApplyEndDate(user.getApplyEndDate().toString());
			response.setUserInfo(userinfoRequest);
			response.setIsSuccess(true);
			if (user != null) {
				response.setMessage("User Information success");
			} else {
				response.setMessage("No User information Available");
			}
			response.setErrorCode("200");
			return ResponseEntity.ok().body(response);
		} else {
			response.setIsSuccess(false);
			response.setMessage("Unauthorized Request");
			response.setErrorCode("99");
			return ResponseEntity.status(400).body(response);
		}
	}
	
	@RequestMapping(value="/getUserRole", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> getUserRole(Principal principal,@RequestHeader HttpHeaders headers) {
		
		CommonGetResponse resp = new CommonGetResponse();
		GetUserRoleObjResponse userRoleResponse = new GetUserRoleObjResponse();
		List<String> clientIds = headers.getValuesAsList("clientId");
		List<String> clientSecrets = headers.getValuesAsList("clientSecret");
		
		Systems systems = systemsRepository.findSystemIdByClientIdSecret(clientIds.get(0),clientSecrets.get(0));
		if(systems==null) {
			resp.setIsSuccess(false);
			resp.setMessage("clientId or clientSecret invalid");
			resp.setErrorCode("9999");
			return  ResponseEntity.status(200).body(resp);
		}
		if (principal == null) {
			return null;
		}	else {
			String userLogId = principal.getName();
			User user = userRepository.findByUserLogId(userLogId);
			List<BigInteger> systemRoleIds =  systemsRoleRepository.getSystemRoleIdbySystemId(systems.getSystemId());
			Long[] systemRoleIdsLong = new Long[systemRoleIds.size()];
			int i=0;
			for(BigInteger sysRoleId: systemRoleIds) {
				systemRoleIdsLong[i] = sysRoleId.longValue();
				i++;
			}
			List<Role> roleEntityList = userSystemsRoleRepository.getRolesBySystemRoleUserId(user.getUserId().toString(),systemRoleIdsLong);
			for (Role role : roleEntityList) {
				userRoleResponse.setWorkGrpNo(role.getNumber().toString());
			}
			userRoleResponse.setIsSuccess(true);
			userRoleResponse.setMessage("UserRole Available");
			userRoleResponse.setErrorCode("200");
			return  ResponseEntity.status(200).body(userRoleResponse);
		}
	}
	
	// Get Resources which are assigned to user
	@RequestMapping(value="/getUserResource", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> getUserResource(Principal principal, @RequestHeader HttpHeaders headers) {
		CommonGetResponse resp = new CommonGetResponse();
		GetUserResourceObjResponse userRoleResponse = new GetUserResourceObjResponse();
		GetUserResourceObj resourceObj = null;
		List<GetUserResourceObj> resourceObjList = new ArrayList<>();
		List<String> clientIds = headers.getValuesAsList("clientId");
		List<String> clientSecrets = headers.getValuesAsList("clientSecret");
		Systems systems = systemsRepository.findSystemIdByClientIdSecret(clientIds.get(0),clientSecrets.get(0));
		if(systems==null) {
			resp.setIsSuccess(false);
			resp.setMessage("clientId or clientSecret invalid");
			resp.setErrorCode("9999");
			return  ResponseEntity.status(200).body(resp);
		}
		if (principal == null) {
			return null;
		}	else {
			String userLogId = principal.getName();
			User user = userRepository.findByUserLogId(userLogId);
			
			//get system_role_id from system_role table.
			List<BigInteger> systemRoleIds = systemsRoleRepository.getSystemRoleIdbySystemId(systems.getSystemId());
			Long[] systemRoleIdsLong = new Long[systemRoleIds.size()];
			int i=0;
			for(BigInteger sysRoleId: systemRoleIds) {
				systemRoleIdsLong[i] = sysRoleId.longValue();
				i++;
			}
			BigInteger userSystemRoleId = userSystemsRoleRepository.getUserSystemRoleIdBySystemUser(user.getUserId(),systemRoleIdsLong);
			if(userSystemRoleId==null) {
				return null;
			}
			List<Resource> resourceList = userSystemsResourceRepository.getResourceByUserId(userSystemRoleId.toString());
			for (Resource resource : resourceList) {
				resourceObj = new GetUserResourceObj();
				resourceObj.setResourcePath(resource.getPath());
				resourceObj.setResourceDesc(resource.getDescription());
				resourceObjList.add(resourceObj);
			}
			userRoleResponse.setSuccess(true);
			userRoleResponse.setErrorCode("200");
			userRoleResponse.setMessage("Resource List Available");
			userRoleResponse.setResourceList(resourceObjList);
			return  ResponseEntity.status(200).body(userRoleResponse);
		}
	}
	
	@RequestMapping(value="/changeUserInfo", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> editUser(@RequestHeader HttpHeaders headers, @RequestBody UserInfoRequestObj userRequestObj,Principal principal) {
		
		//Check AccessToken &&  client validation
		CommonGetResponse resp = new CommonGetResponse();
		List<String> clientIds = headers.getValuesAsList("clientId");
		List<String> clientSecrets = headers.getValuesAsList("clientSecret");
		List<String> accessTokens = headers.getValuesAsList("accessToken");
		if (principal == null) {
			return null;
		}	else {
			String userLogId = principal.getName();
			User user = userRepository.findByUserLogId(userLogId);
			Systems systems = systemsRepository.findSystemIdByClientIdSecret(clientIds.get(0),clientSecrets.get(0));
			if(systems==null) {
				resp.setIsSuccess(false);
				resp.setMessage("clientId or clientSecret invalid");
				resp.setErrorCode("9999");
				return  ResponseEntity.status(200).body(resp);
			}
			List<BigInteger> systemRoleIds =  systemsRoleRepository.getSystemRoleIdbySystemId(systems.getSystemId());
			Long[] systemRoleIdsLong = new Long[systemRoleIds.size()];
			int i=0;
			for(BigInteger sysRoleId: systemRoleIds) {
				systemRoleIdsLong[i] = sysRoleId.longValue();
				i++;
			}
			//get user assigned System
			BigInteger assignedUserSystem = userSystemsRoleRepository.getUserSystemRoleIdBySystemUser(user.getUserId(), systemRoleIdsLong);
			if(assignedUserSystem==null) {
				resp.setIsSuccess(false);
				resp.setMessage("clientId or clientSecret invalid");
				resp.setErrorCode("9999");
				return  ResponseEntity.status(200).body(resp);
			}
			
			UserSystemsRole userSystemRole = null;
			UserInfoRequest userRequest = userRequestObj.getUserInfo();
			user = userRepository.findByUserLogId(userRequest.getUserId());
			try {
				
			    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			    if(userRequest.getUseApplyStartDate()!=null || userRequest.getUseApplyStartDate()!="") {
			    	java.util.Date date = dateFormat.parse(userRequest.getUseApplyStartDate());
			    	java.sql.Date sqlStartDate = new java.sql.Date(date.getTime());
			    	user.setApplyStartDate(sqlStartDate);
			    }
			    if(userRequest.getUseApplyEndDate()!=null || userRequest.getUseApplyEndDate()!="") {
			    	java.util.Date date = dateFormat.parse(userRequest.getUseApplyEndDate());
			    	java.sql.Date sqlEndDate = new java.sql.Date(date.getTime());
			    	user.setApplyEndDate(sqlEndDate);
			    }
			} catch(Exception e) {
			     System.out.println("Date Format Exception:"+e.getMessage());
			}
			if(userRequest.getEmailAddress()!=null || userRequest.getEmailAddress()!="") {
				user.setEmail(userRequest.getEmailAddress());
			}
			boolean isUseBool = userRequest.getUseYn();
			if(isUseBool) {
				user.setIsUse(1L);
			} else {
				user.setIsUse(0L);
			}
			user.setMobile(Long.parseLong(userRequest.getMobileNo()));
			user.setTelephone_No(Long.parseLong(userRequest.getTelNo()));
			user.setUserLogId(userRequest.getUserId());
			user.setUserName(userRequest.getUserNm());			
			User user1 = userRepository.save(user);
			if(user1==null) {
				resp.setIsSuccess(false);
				resp.setMessage("Application Error");
				resp.setErrorCode("99");
				return  ResponseEntity.status(200).body(resp);	
			}
			resp.setIsSuccess(true);
			resp.setMessage("User Info Changes Successfull");
			resp.setErrorCode("200");
			return  ResponseEntity.status(200).body(resp);
		}
		/*for (String systemRoleId : systemRoleIds) {
			boolean isSystemRoleExist = userSystemsRoleRepository.existsById(Long.parseLong(systemRoleId));
			//List<Long> existsystemIds = userSystemsRoleRepository.getSystemIdByUserId(user1.getUserId());
			if(isSystemRoleExist) {
			} else {
				userSystemRole = new UserSystemsRole();
				systemRoleEntity = new SystemsRole();
				systemRoleEntity = systemsRoleRepository.getOne(Long.parseLong(systemRoleId));
				userSystemRole.setSystemRole(systemRoleEntity);
				if(isUseBool) {
					userSystemRole.setIsUse(1);
				} else {
					userSystemRole.setIsUse(0);
				}
				usrStatus = userSystemsRoleRepository.save(userSystemRole);
			}
		}*/		
	} // End of changeUserInfo Api
	
	@RequestMapping(value="/changeUserPw", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> updatePassword(@RequestHeader HttpHeaders headers, @RequestBody PasswordRequestResp pwdReqResp, Principal principal) {
		CommonGetResponse resp = new CommonGetResponse();
		List<String> clientIds = headers.getValuesAsList("clientId");
		List<String> clientSecrets = headers.getValuesAsList("clientSecret");
		List<String> accessTokens = headers.getValuesAsList("accessToken");
		if (principal == null) {
			return null;
		}	else {
			String userLogId = principal.getName();
			User user = userRepository.findByUserLogId(userLogId);
			Systems systems = systemsRepository.findSystemIdByClientIdSecret(clientIds.get(0),clientSecrets.get(0));
			if(systems==null) {
				resp.setIsSuccess(false);
				resp.setMessage("clientId or clientSecret invalid");
				resp.setErrorCode("9999");
				return  ResponseEntity.status(200).body(resp);
			}
			String password = PasswordUtil.getPasswordHash(pwdReqResp.getUserPwOld());
			boolean successStatus = PasswordUtil.matchPassword(pwdReqResp.getUserPwOld(), user.getPassword());
			if (successStatus) {
				user.setPassword(pwdReqResp.getUserPwNew());
				userService.save(user);
				resp.setIsSuccess(true);
				resp.setMessage("Set Password Success");
				resp.setErrorCode("200");
				return  ResponseEntity.ok().body(resp);
			} else {
				resp.setIsSuccess(false);
				resp.setMessage("Old Password Does not match");
				resp.setErrorCode("200");
				return  ResponseEntity.ok().body(resp);
			}
		}
	}

	/*@RequestMapping(value="/resetUserPw", method = RequestMethod.POST,
	consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> resetPassword(@RequestHeader HttpHeaders headers,@RequestBody PasswordRequestResp pwdReqResp, Principal principal) {
		try {
			if (principal != null) {
				String htmlData = "localhost:8081/uas/setpassword/(userId)?newPassword=(Insert new password)";
				String subject = "Reset Your Password ElandUAS";
				return new ResponseEntity<>(userService.sendEmail(pwdReqResp.getEmail(), subject, htmlData), HttpStatus.OK);
			} else {
				return new ResponseEntity<>("Unauthorized Request", HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			return new ResponseEntity<>("Mail Not Sent", HttpStatus.INTERNAL_SERVER_ERROR);
		}
	}*/
	
	@RequestMapping(value="/resetUserPw", method = RequestMethod.POST,
	consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> resetPassword(@RequestHeader HttpHeaders headers,@RequestBody ResetPasswordRequest resetPwdReq) {
		CommonGetResponse resp = new CommonGetResponse();
		List<String> clientIds = headers.getValuesAsList("clientId");
		List<String> clientSecrets = headers.getValuesAsList("clientSecret");
		String userLogId = resetPwdReq.getUserId();
		User user = userRepository.findByUserLogId(userLogId);
		Systems systems = systemsRepository.findSystemIdByClientIdSecret(clientIds.get(0),clientSecrets.get(0));
		if(systems==null) {
			resp.setIsSuccess(false);
			resp.setMessage("clientId or clientSecret invalid");
			resp.setErrorCode("9999");
			return  ResponseEntity.status(200).body(resp);
		}
		user.setPassword(resetPwdReq.getUserPw());
		userService.save(user);
		resp.setIsSuccess(true);
		resp.setMessage("Reset Password Success");
		resp.setErrorCode("200");
		return  ResponseEntity.ok().body(resp);
	}
	
	//set role list
	@RequestMapping(value="/setRoleList", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> setRoleList(@RequestHeader HttpHeaders headers, @RequestBody SetRoleObjListRequest roleListRequest,Principal principal) {
	
		CommonGetResponse resp = new CommonGetResponse();
		List<String> clientIds = headers.getValuesAsList("clientId");
		List<String> clientSecrets = headers.getValuesAsList("clientSecret");
		List<String> accessTokens = headers.getValuesAsList("accessToken");
		if (principal == null) {
			return null;
		} else {
			String userLogId = principal.getName();
			User user = userRepository.findByUserLogId(userLogId);
			Systems systems = systemsRepository.findSystemIdByClientIdSecret(clientIds.get(0),clientSecrets.get(0));
			if(systems==null) {
				resp.setIsSuccess(false);
				resp.setMessage("clientId or clientSecret invalid");
				resp.setErrorCode("9999");
				return  ResponseEntity.status(200).body(resp);
			}
			List<SetRoleObj> roleList = roleListRequest.getRoleInfoList();
			for (SetRoleObj setRoleObj : roleList) {
				
				String workGrpNo = setRoleObj.getWorkGrpNo();
				String workGrpDesc = setRoleObj.getWorkGrpDesc();
				Boolean useYn = setRoleObj.getUseYn();
				Role roleEntity = roleRepository.findRoleByNameNo(Long.parseLong(workGrpNo));
				System.out.println("Role:"+roleEntity);
				if(roleEntity==null) {
					return null;
				}
				// Check system_role combination  exist or not
				SystemsRole systemRoleEntity = systemsRoleRepository.getSystemRoleByRoleIdSystemId(systems.getSystemId(),roleEntity.getRoleId());
				System.out.println("Role:"+systemRoleEntity);
				if(systemRoleEntity == null) {
					//Register
					SystemsRole newSystemRoleEntity = new SystemsRole();
					newSystemRoleEntity.setSystem(systems);
					newSystemRoleEntity.setRole(roleEntity);
					newSystemRoleEntity.setDescription(workGrpDesc);
					if(useYn) {
						newSystemRoleEntity.setIs_use(1L);
					} else {
						newSystemRoleEntity.setIs_use(0L);
					}
					systemsRoleRepository.flush();
					systemsRoleRepository.save(newSystemRoleEntity);
					resp.setIsSuccess(true);
					resp.setMessage("Set RoleList Success");
					resp.setErrorCode("200");
					return  ResponseEntity.ok().body(resp);
				} else {
					//Update
					systemRoleEntity.setDescription(workGrpDesc);
					if(useYn) {
						systemRoleEntity.setIs_use(1L);
					} else {
						systemRoleEntity.setIs_use(0L);
					}
					systemsRoleRepository.save(systemRoleEntity);
					resp.setIsSuccess(true);
					resp.setMessage("Set RoleList Success");
					resp.setErrorCode("200");
					return  ResponseEntity.ok().body(resp);
				}
			}
		}
		return null;
	} //setRoleList Api End
	
	//set role list
		@RequestMapping(value="/setResourceList", method = RequestMethod.POST,
				consumes = "application/json", produces = "application/json")
		public ResponseEntity<?> setResourceList(@RequestHeader HttpHeaders headers, @RequestBody SetResourceObjListRequest resourceListRequest,Principal principal) {
		
			CommonGetResponse resp = new CommonGetResponse();
			List<String> clientIds = headers.getValuesAsList("clientId");
			List<String> clientSecrets = headers.getValuesAsList("clientSecret");
			List<String> accessTokens = headers.getValuesAsList("accessToken");
			if (principal == null) {
				return null;
			} else {
				String userLogId = principal.getName();
				User user = userRepository.findByUserLogId(userLogId);
				Systems systems = systemsRepository.findSystemIdByClientIdSecret(clientIds.get(0),clientSecrets.get(0));
				if(systems==null) {
					resp.setIsSuccess(false);
					resp.setMessage("clientId or clientSecret invalid");
					resp.setErrorCode("9999");
					return  ResponseEntity.status(200).body(resp);
				}
				List<SetResourceObj> resourceList = resourceListRequest.getResourceInfoList();
				for (SetResourceObj setResourceObj : resourceList) {
					
					String resourcePath = setResourceObj.getResourcePath();
					String resourceDesc = setResourceObj.getResourceDesc();
					Boolean useYn = setResourceObj.getUseYn();
					List<Resource> resourceEntityList = resourceRepository.getResourceByPath(resourcePath);
					if(resourceEntityList.size()==0) {
						return null;
					}
					Long resId = resourceEntityList.get(0).getResourceId();
					// Check system_role combination  exist or not
					SystemsResource systemResourceEntity = systemsResourceRepository.getResourceBySystemId(systems.getSystemId(),resourceEntityList.get(0).getResourceId());
					if(systemResourceEntity == null) {
						resourceRepository.flush();
						resourceEntityList.get(0).setDescription(resourceDesc);
						Resource newResourceEntity = resourceRepository.save(resourceEntityList.get(0));
						//Register
						SystemsResource newSystemResourceEntity = new SystemsResource();
						newSystemResourceEntity.setSystem(systems);
						newSystemResourceEntity.setResource(newResourceEntity);
						if(useYn) {
							newSystemResourceEntity.setIsUse(1L);
						} else {
							newSystemResourceEntity.setIsUse(0L);
						}
						systemsResourceRepository.flush();
						systemsResourceRepository.save(newSystemResourceEntity);
						resp.setIsSuccess(true);
						resp.setMessage("Set ResourceList Success");
						resp.setErrorCode("200");
						return  ResponseEntity.ok().body(resp);
					} else {
						//Update
						resourceEntityList.get(0).setDescription(resourceDesc);
						resourceRepository.flush();
						resourceRepository.save(resourceEntityList.get(0));
						if(useYn) {
							systemResourceEntity.setIsUse(1L);
						} else {
							systemResourceEntity.setIsUse(0L);
						}
						systemsResourceRepository.save(systemResourceEntity);
						resp.setIsSuccess(true);
						resp.setMessage("Set ResourceList Success");
						resp.setErrorCode("200");
						return  ResponseEntity.ok().body(resp);
					}
				}
			}
			return null;
		} //setRoleList Api End
	
	/*
	 * SOURCE SYSTEM USER API ENDS
	 */
}
