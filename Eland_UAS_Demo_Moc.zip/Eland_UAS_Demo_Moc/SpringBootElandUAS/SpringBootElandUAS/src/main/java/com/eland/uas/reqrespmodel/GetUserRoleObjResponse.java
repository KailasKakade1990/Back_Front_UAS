package com.eland.uas.reqrespmodel;

public class GetUserRoleObjResponse {

	private boolean isSuccess;
	private String message;
	private String errorCode;
	private String workGrpNo;
	
	public boolean getIsSuccess() {
		return isSuccess;
	}
	public void setIsSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getWorkGrpNo() {
		return workGrpNo;
	}
	public void setWorkGrpNo(String workGrpNo) {
		this.workGrpNo = workGrpNo;
	}
	
}
