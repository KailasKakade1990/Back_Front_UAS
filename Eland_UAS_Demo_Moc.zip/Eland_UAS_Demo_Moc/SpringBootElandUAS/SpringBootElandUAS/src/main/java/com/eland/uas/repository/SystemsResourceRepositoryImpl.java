package com.eland.uas.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.eland.uas.entity.Resource;
import com.eland.uas.entity.Role;
import com.eland.uas.entity.SystemsResource;
import com.eland.uas.entity.SystemsRole;

@Repository
@Transactional(readOnly = true)
public class SystemsResourceRepositoryImpl implements CustomSystemsResourceRepository{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public List<SystemsResource> getResourceBySystemId(String systemId) {
		Query query = entityManager.createNativeQuery("select * from resource r inner join system_resource sr on(r.resource_id=sr.resource_id) where sr.system_id="+systemId+" and sr.is_use=1 GROUP BY sr.resource_id ", SystemsResource.class);
		
		return query.getResultList();
	}

	@Override
	public SystemsResource getResourceBySystemId(Long systemId, Long resourceId) {
		Query query = entityManager.createNativeQuery("select * from system_resource where system_id="+systemId+" and resource_id="+resourceId+" ", SystemsResource.class);
		
		SystemsResource systemResourceEntity = null;
		try {
			systemResourceEntity = (SystemsResource) query.getSingleResult();
			return systemResourceEntity;	
		} catch (Exception e) {
			e.printStackTrace();
			return systemResourceEntity;	
		}
	}
}
