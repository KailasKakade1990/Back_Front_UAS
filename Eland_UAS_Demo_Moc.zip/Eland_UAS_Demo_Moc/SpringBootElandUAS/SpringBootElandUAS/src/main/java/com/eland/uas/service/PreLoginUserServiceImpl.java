package com.eland.uas.service;

import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.mail.Authenticator;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.eland.uas.UserRepository1;
import com.eland.uas.entity.User;
import com.eland.uas.passwordutil.PasswordUtil;

@Service
@Transactional
public class PreLoginUserServiceImpl implements PreLoginUserService {

	@Autowired
	UserRepository1 userRepository;

//	@Autowired
//	ResourceRepo resourcerepo;
//	@Autowired
//	AdminRepo adminrepo;
//
//	@Autowired
//	SystemRepo systemrepo;
//	@Autowired
//	UserResourceRepository userResourceRepo;
	@Override
	public User save(User user) {

		String password = PasswordUtil.getPasswordHash(user.getPassword());
		user.setPassword(password);
		// user.setCreatedDate(new Date());
		userRepository.save(user);
		return user;
	}

	@Override
	public List<User> findAll() {
		// TODO Auto-generated method stub
		return (List<User>) userRepository.findAll();
	}

	@Override
	public User getUserByUserId(String email) {
		// TODO Auto-generated method stub
		return userRepository.findByUserLogId(email);
	}

	@Override
	public boolean sendEmail(String email, String emailSubject, String bodyData) {
		try {
			// String host = "45.64.105.172";
			String host = "smtp.gmail.com";
			String to = email;
			String user = "kailaskakade90@gmail.com";// mail id
			String password = "Kailasphp@123...";// provide your gmail password and * Note: Make your mail security less
													// secure *
			String htmlData = bodyData;
			String subject = emailSubject;

			Properties properties = System.getProperties();
			properties.put("mail.smtp.starttls.enable", "true");
			properties.put("mail.smtp.host", host);
			properties.put("mail.smtp.user", user);
			properties.put("mail.smtp.password", password);
			properties.put("mail.smtp.port", "587");
			properties.put("mail.smtp.auth", "true");

			Session session = Session.getDefaultInstance(properties, new Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(user, password);
				}
			});
			try {
				StringTokenizer st = new StringTokenizer(to, ",; ");
				while (st.hasMoreTokens()) {
					try {
						MimeMessage message = new MimeMessage(session);
						message.setFrom(new InternetAddress(user));
						message.addRecipient(Message.RecipientType.TO, new InternetAddress(st.nextToken()));
						message.setSubject(subject);
						BodyPart messageBodyPart1 = new MimeBodyPart();
						messageBodyPart1.setContent(htmlData, "text/html");
						Multipart multipart = new MimeMultipart();
						multipart.addBodyPart(messageBodyPart1);
						message.setContent(multipart);

						Transport.send(message);
						System.out.println("message sent....");
					} catch (Exception e) {
						System.out.println(e);
					}
				}
				return true;

			} catch (Exception ex) {
				ex.printStackTrace();
			}

		} catch (Exception e) {
			System.out.println(e);
		}
		return false;
	}

}
