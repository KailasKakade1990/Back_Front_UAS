package com.eland.uas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "system_resource_user")
public class SystemResourceUser {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "system_resource_user_id")
	private Long systemResourceUserId;
	@ManyToOne
	@JoinColumn(name = "user_system_role_id")
	private UserSystemsRole usersystemRole;
	@ManyToOne
	@JoinColumn(name = "system_resource_id")
	private SystemsResource systemResource;

	
	public Long getSystemResourceUserId() {
		return systemResourceUserId;
	}
	public void setSystemResourceUserId(Long systemResourceUserId) {
		this.systemResourceUserId = systemResourceUserId;
	}
	public UserSystemsRole getUsersystemRole() {
		return usersystemRole;
	}
	public void setUsersystemRole(UserSystemsRole usersystemRole) {
		this.usersystemRole = usersystemRole;
	}
	public SystemsResource getSystemResource() {
		return systemResource;
	}
	public void setSystemResource(SystemsResource systemResource) {
		this.systemResource = systemResource;
	}
}
