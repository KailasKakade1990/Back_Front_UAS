package com.eland.uas.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.eland.uas.entity.Resource;
import com.eland.uas.entity.RoleSystemResource;
import com.eland.uas.entity.SystemsResource;

@Repository
public interface RoleSystemResourceRepository extends JpaRepository<RoleSystemResource, Long>, CustomRoleSystemResourceRepository {

	//List<SystemsResource> getResourceByRoleId(String systemRoleId);
}
