package com.eland.uas.service;

import java.util.List;

public interface UserService {

	Long accountNoGeneration(Long maxnoList);
}
