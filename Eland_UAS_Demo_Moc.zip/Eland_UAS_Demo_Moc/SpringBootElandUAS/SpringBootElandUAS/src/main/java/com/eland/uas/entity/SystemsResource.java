package com.eland.uas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name = "system_resource")
public class SystemsResource {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "system_resource_id")
	private Long resourceDetailId;
	
	@ManyToOne
	@JoinColumn(name = "system_id")
	private Systems system;
	
	@ManyToOne
	@JoinColumn(name = "resource_id")
	private Resource resource;
	
	/*@Transient
	private Long[] system_id;
	@Transient
	private Long[] resource_id;*/
	
	public Systems getSystem() {
		return system;
	}
	public void setSystem(Systems system) {
		this.system = system;
	}

	public Resource getResource() {
		return resource;
	}

	public void setResource(Resource resource) {
		this.resource = resource;
	}

	@Column(name = "is_use",columnDefinition = "BIGINT(20) default 1")
	private Long isUse;
	@Column(name = "role_count",columnDefinition = "BIGINT(20) default 0")
	private Long roleCount;
	@Column(name = "user_count",columnDefinition = "BIGINT(20) default 0")
	private Long userCount;

	public Long getResourceDetailId() {
		return resourceDetailId;
	}

	public void setResourceDetailId(Long resourceDetailId) {
		this.resourceDetailId = resourceDetailId;
	}

	/*
	 * public Long getSystemId() { return systemId; }
	 * 
	 * public void setSystemId(Long systemId) { this.systemId = systemId; }
	 * 
	 * public Long getResourceId() { return resourceId; }
	 * 
	 * public void setResourceId(Long resourceId) { this.resourceId = resourceId;
	 * }
	 */

	public Long getIsUse() {
		return isUse;
	}

	public void setIsUse(Long isUse) {
		this.isUse = isUse;
	}

	public Long getRoleCount() {
		return roleCount;
	}

	public void setRoleCount(Long roleCount) {
		this.roleCount = roleCount;
	}

	public Long getUserCount() {
		return userCount;
	}

	public void setUserCount(Long userCount) {
		this.userCount = userCount;
	}
	
/*	public Long[] getSystem_id() {
		return system_id;
	}
	public void setSystem_id(Long[] system_id) {
		this.system_id = system_id;
	}
	
	public Long[] getResource_id() {
		return resource_id;
	}
	public void setResource_id(Long[] resource_id) {
		this.resource_id = resource_id;
	}
*/
}
