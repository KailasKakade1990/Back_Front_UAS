package com.eland.uas.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.eland.uas.entity.Resource;
import com.eland.uas.entity.RoleSystemResource;
import com.eland.uas.entity.SystemsResource;

@Repository
public interface CustomRoleSystemResourceRepository {

	List<SystemsResource> getResourceByRoleId(String systemRoleId);
	List<RoleSystemResource> getRoleSystemResourceByRole(Long systemRoleId);

}
