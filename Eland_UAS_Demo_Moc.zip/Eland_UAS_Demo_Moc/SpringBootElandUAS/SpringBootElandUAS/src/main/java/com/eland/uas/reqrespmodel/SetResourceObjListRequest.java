package com.eland.uas.reqrespmodel;

import java.util.List;

public class SetResourceObjListRequest {

	private List<SetResourceObj> resourceInfoList;

	public List<SetResourceObj> getResourceInfoList() {
		return resourceInfoList;
	}

	public void setResourceInfoList(List<SetResourceObj> resourceInfoList) {
		this.resourceInfoList = resourceInfoList;
	}
	
}