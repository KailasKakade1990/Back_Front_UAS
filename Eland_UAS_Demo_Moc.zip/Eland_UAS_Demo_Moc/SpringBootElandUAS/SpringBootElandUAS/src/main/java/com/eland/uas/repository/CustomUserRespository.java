package com.eland.uas.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.eland.uas.entity.User;

public interface CustomUserRespository {

	Long getMaxByAccountNo(String userName);
	User getUserByUserName(String userName); 
	List<Long> getAccountNoByUserName(String userName);
}
