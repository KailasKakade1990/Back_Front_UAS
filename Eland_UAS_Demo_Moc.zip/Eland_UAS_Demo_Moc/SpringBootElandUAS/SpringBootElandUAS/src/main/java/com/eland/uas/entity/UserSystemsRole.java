package com.eland.uas.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "user_system_role")
public class UserSystemsRole implements Serializable {

	private static final long serialVersionUID = -7230396126349228044L;
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_system_role_id")
	private Long userSystemRoleId;

	@ManyToOne
	@JoinColumn(name = "user_id", nullable = false)
	private User user;

	@ManyToOne
	@JoinColumn(name = "system_role_id", nullable = false)
	private SystemsRole systemRole;

	@Column(name = "is_use", columnDefinition = "BIGINT(20) default 1")
	private Long isUse;

	@Column(name = "resource_count", columnDefinition = "int default 0")
	private Integer resourceCount;

	public Long getUserSystemRoleId() {
		return userSystemRoleId;
	}

	public void setUserSystemRoleId(Long userSystemRoleId) {
		this.userSystemRoleId = userSystemRoleId;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public SystemsRole getSystemRole() {
		return systemRole;
	}

	public void setSystemRole(SystemsRole systemRole) {
		this.systemRole = systemRole;
	}

	public Long getIsUse() {
		return isUse;
	}

	public void setIsUse(Long isUse) {
		this.isUse = isUse;
	}

	public Integer getResourceCount() {
		return resourceCount;
	}

	public void setResourceCount(Integer resourceCount) {
		this.resourceCount = resourceCount;
	}
}
