package com.eland.uas.controller;

import java.io.UnsupportedEncodingException;
import java.math.BigInteger;
import java.security.Principal;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.eland.uas.entity.Otp;
import com.eland.uas.entity.Resource;
import com.eland.uas.entity.Role;
import com.eland.uas.entity.RoleSystemResource;
import com.eland.uas.entity.SystemOtp;
import com.eland.uas.entity.Systems;
import com.eland.uas.entity.SystemsResource;
import com.eland.uas.entity.SystemsRole;
import com.eland.uas.entity.User;
import com.eland.uas.entity.UserSystemResource;
import com.eland.uas.entity.UserSystemsRole;
import com.eland.uas.repository.OtpRepository;
import com.eland.uas.repository.ResourceRepository;
import com.eland.uas.repository.RoleRepository;
import com.eland.uas.repository.RoleSystemResourceRepository;
import com.eland.uas.repository.SystemOtpRepository;
import com.eland.uas.repository.SystemsResourceRepository;
import com.eland.uas.repository.SystemsRespository;
import com.eland.uas.repository.SystemsRoleRepository;
import com.eland.uas.repository.UserRepository;
import com.eland.uas.repository.UserSystemsResourceRepository;
import com.eland.uas.repository.UserSystemsRoleRepository;
import com.eland.uas.reqresp.OtpValidateRequest;
import com.eland.uas.reqresp.SetRoleRequest;
import com.eland.uas.reqresp.SystemOtpRequest;
import com.eland.uas.reqrespmodel.CommonGetInfoResponse;
import com.eland.uas.reqrespmodel.CommonGetResponse;
import com.eland.uas.reqrespmodel.CommonResponse;
import com.eland.uas.reqrespmodel.GetInfoMinimulRequest;
import com.eland.uas.reqrespmodel.ResourceRequest;
import com.eland.uas.reqrespmodel.RoleRequest;
import com.eland.uas.reqrespmodel.SetUserSystemResource;
import com.eland.uas.reqrespmodel.SystemsRequest;
import com.eland.uas.reqrespmodel.UserInfoRequest;
import com.eland.uas.reqrespmodel.UserInfoRequestObj;
import com.eland.uas.reqrespmodel.UserInfoResponse;
import com.eland.uas.reqrespmodel.UserRequest;
import com.eland.uas.service.PreLoginUserService;
import com.eland.uas.service.UserService;

@RestController
@RequestMapping("/uas")
@CrossOrigin(origins = "*", allowedHeaders = "*")
public class AdminController {
	private static final Logger logger = LoggerFactory.getLogger(AdminController.class);

	@Autowired
	private ResourceRepository resourceRepository;
	@Autowired
	private RoleRepository roleRepository;
	@Autowired
	private SystemsResourceRepository systemsResourceRepository;
	@Autowired
	private SystemsRespository systemsRepository;
	@Autowired
	private SystemsRoleRepository systemsRoleRepository;
	@Autowired
	private UserRepository userRepository;
	@Autowired
	private UserSystemsRoleRepository userSystemsRoleRepository;
	@Autowired
	private UserSystemsResourceRepository userSystemsResourceRepository;
	@Autowired
	private RoleSystemResourceRepository roleSystemsResourceRepository;
	@Autowired
	private PreLoginUserService userService;
	@Autowired
	private SystemOtpRepository systemOtpRepository;
	@Autowired
	private OtpRepository otpRepository;
	@Autowired
	UserService userService1;
	HttpHeaders respHeader = new HttpHeaders();

	/*
	// getdata for Unassign/Assign Role to SystemResource
	@RequestMapping(value="/getRoleSystem", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> getRoleBySystemId(@RequestHeader HttpHeaders headers, @RequestBody Object obj ) {
		String tokenS = "token1234";
		System.out.println("Header Token:"+headers.get("accesstoken"));
		//return userSystemsRoleRepository.getRoleBySystemId(systemId);
		String token = headers.get("accessToken").toString();
		if(tokenS.equals(token)) {
			System.out.println("True");
		}
		return null;
	}
	
	// getdata for Unassign/Assign User to SystemResource
	@GetMapping("/getUserBySystemId/{systemId}")
	public List<User> getUserBySystemId(@PathVariable Long systemId) {
		return userSystemsRoleRepository.getUserBySystemId(systemId);
	}
	
	// getdata for Unassign/Assign SystemResource to Role
	@GetMapping("/getResourceBySystemId/{roleId}")
	public List<Resource> getResourceBySystemId(@PathVariable Long systemId) {
		return systemsResourceRepository.getResourceBySystemId(systemId);
	}

	// getd
	@GetMapping("/assignRoleSystemResource")
	public List<Resource> assignRoleSystemResource(@PathVariable Long systemId) {
		return systemsResourceRepository.getResourceBySystemId(systemId);
	}
	
	@GetMapping("/getAssignRoleSystemResource")
	public List<Role> getAssignRoleSystemResource(@PathVariable Long systemId) {
		return systemsResourceRepository.getResourceBySystemId(systemId);
	}
	}*/

	
	
	/*
	 * Add API's STARTS
	 */
	
	@RequestMapping(value="/addSystem", method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE,
			consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> addSystem(@RequestBody SystemsRequest systemRequest) {
		
		Systems system = new Systems();
		Systems systemEntity = null;
		system.setName(systemRequest.getName());
		system.setDescription(systemRequest.getDescription());
		CommonResponse response = new CommonResponse();

		//convert client Id & client Secret to Base 64
		String clientIdbase64encoded = null;
		String clientSecbase64encoded = null;
		try {
			clientIdbase64encoded = Base64.getEncoder().encodeToString(systemRequest.getClientId().getBytes("utf-8"));
			clientSecbase64encoded = Base64.getEncoder().encodeToString(systemRequest.getClientSecret().getBytes("utf-8"));
	        System.out.println("Base64 Encoded String (Basic) :" + clientIdbase64encoded);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		system.setClientId(clientIdbase64encoded);
		system.setClientSecret(clientSecbase64encoded);
		system.setInOtpUse(systemRequest.getInOtpUse());
		system.setIsUse(systemRequest.getIsUse());
		try {
			systemEntity = systemsRepository.save(system);
		}catch(Exception e) {
			response.setSuccess(false);
			response.setMessage("Given SystemId or ClientId/Secret is Already Available");
			response.setCode("99");
			return  ResponseEntity.ok().body(response);
		}
		if(systemEntity!=null) {
			response.setSuccess(true);
			response.setMessage("System Added Successfully");
			response.setCode("200");
			return  ResponseEntity.ok().body(response);
		} else {
			response.setSuccess(false);
			response.setMessage("Add System not success");
			response.setCode("99");
			return  ResponseEntity.ok().body(response);
		}
	}
	
	
	@RequestMapping(value="/editSystem", method = RequestMethod.POST,produces = MediaType.APPLICATION_JSON_VALUE,
			consumes=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<CommonResponse> editSystem(@RequestBody SystemsRequest systemRequest) {
		
		Systems system = systemsRepository.getOne(systemRequest.getSystemId());
		system.setName(systemRequest.getName());
		system.setDescription(systemRequest.getDescription());
		
		//convert client Id & client Secret to Base 64
		String clientIdbase64encoded = null;
		String clientSecbase64encoded = null;
		try {
			clientIdbase64encoded = Base64.getEncoder().encodeToString(systemRequest.getClientId().getBytes("utf-8"));
			clientSecbase64encoded = Base64.getEncoder().encodeToString(systemRequest.getClientSecret().getBytes("utf-8"));
	         System.out.println("Base64 Encoded String (Basic) :" + clientIdbase64encoded);
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		system.setClientId(clientIdbase64encoded);
		system.setClientSecret(clientSecbase64encoded);
		system.setInOtpUse(systemRequest.getInOtpUse());
		system.setIsUse(systemRequest.getIsUse());
		
		Systems systemEntity = systemsRepository.save(system);
		CommonResponse response = new CommonResponse();
		if(systemEntity!=null) {
			response.setSuccess(true);
			response.setMessage("Edit System success");
			response.setCode("200");
			//response.setAccessToken(headers.get("accessToken").get(0));
			//respHeader.add("accessToken", headers.get("accessToken").get(0));
			return  ResponseEntity.ok().body(response);
		} else {
			response.setSuccess(false);
			response.setMessage("Edit System not success");
			response.setCode("99");
			return  ResponseEntity.ok().body(response);
		}
	}
	

	
	@RequestMapping(value="/addRole", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<CommonResponse> addRole(@RequestBody Role role) {
		CommonResponse response = new CommonResponse();
		List<Role> roleExist = roleRepository.findRoleByNameNo(role.getName(),role.getNumber());
		if(roleExist.size()>0) {
			response.setSuccess(false);
			response.setMessage("Role Name and Number already exist");
			response.setCode("200");
			return  ResponseEntity.ok().body(response);
		}
		Role roleEntity = roleRepository.save(role);
		if(roleEntity!=null) {
			response.setMessage("Add Role success");
			response.setSuccess(true);
			response.setCode("200");
			return  ResponseEntity.ok().body(response);
		} else {
			response.setSuccess(false);
			response.setMessage("Add Role not success");
			response.setCode("200");
			return  ResponseEntity.ok().body(response);
		}
	}
	
	
	@RequestMapping(value = "/addUserInfo", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<CommonResponse> addUser(@RequestBody UserRequest userRequest) {

		// Check AccessToken && client validation
		UserSystemsRole userSystemRole = null;
		String[] systemRoleIds = userRequest.getSystemRole();
		User user = new User();

		String userName = userRequest.getUserNm();
		BigInteger accountNo = userSystemsRoleRepository.getAccountNoByUserName(userName);
		if(accountNo==null) {
			BigInteger maxAccountNo = userSystemsRoleRepository.getMaxByAccountNo(userName);
			DateFormat dateFormat = new SimpleDateFormat("YYYYMMDD");
			java.util.Date date = new java.util.Date();
			String formattedDate= dateFormat.format(date);
			System.out.println(formattedDate);
			String lastFourDigits = "";
			Long increment = null;
			if(maxAccountNo!=null) {
				String input =maxAccountNo.toString();     //input string
				     //substring containing last 4 characters
				if (input.length() > 4)
				{
				    lastFourDigits = input.substring(input.length() - 4);
				     increment=Long.parseLong(lastFourDigits);
					 increment++;
				}
				else
				{
					increment = (long) 1001;
				}
			}else {
				increment = (long) 1001;
			}
			String accNo = null;
			accNo = formattedDate+increment;
			user.setAccountNo(Long.parseLong(accNo));
			System.out.println(maxAccountNo);
		} else {			
			user.setAccountNo(accountNo.longValue());
		}
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

			if (userRequest.getApplyStartDate() != null) {
				java.util.Date date = dateFormat.parse(userRequest.getApplyStartDate());
		    	java.sql.Date sqlStartDate = new java.sql.Date(date.getTime());
		    	user.setApplyStartDate(sqlStartDate);
			}
			if (userRequest.getApplyEndDate() != null) {
				java.util.Date date = dateFormat.parse(userRequest.getApplyEndDate());
		    	java.sql.Date sqlEndDate = new java.sql.Date(date.getTime());
		    	user.setApplyEndDate(sqlEndDate);
			}
		} catch (Exception e) {
			System.out.println("Date Format Exception:" + e.getMessage());
		}

		if (userRequest.getEmailAddress() != null || userRequest.getEmailAddress() != "") {
			user.setEmail(userRequest.getEmailAddress());
		}
		boolean isUseBool = userRequest.isUseYn();
		if (isUseBool) {
			user.setIsUse(1L);
		} else {
			user.setIsUse(0L);
		}
		user.setMobile(Long.parseLong(userRequest.getMobileNo()));
		user.setTelephone_No(Long.parseLong(userRequest.getTelNo()));
		user.setUserLogId(userRequest.getUserId());
		user.setUserName(userRequest.getUserNm());
		user.setPassword(userRequest.getUserPw());
		user.setEnabled(userRequest.isEnabled());
		userService.save(user);
		User user1 = userRepository.save(user);
		System.out.println("User1:" + user1);
		SystemsRole systemRoleEntity = null;
		UserSystemsRole usrStatus = null;
		for (String systemRoleId : systemRoleIds) {
			userSystemRole = new UserSystemsRole();
			userSystemRole.setUser(user1);
			systemRoleEntity = new SystemsRole();
			systemRoleEntity = systemsRoleRepository.getOne(Long.parseLong(systemRoleId));
			userSystemRole.setSystemRole(systemRoleEntity);
			if (isUseBool) {
				userSystemRole.setIsUse(1L);
			} else {
				userSystemRole.setIsUse(0L);
			}
			usrStatus = userSystemsRoleRepository.save(userSystemRole);
		}
		CommonResponse response = new CommonResponse();
		if (usrStatus != null) {
			response.setSuccess(true);
			response.setMessage("User Added Successfully");
			response.setCode("200");
			return ResponseEntity.ok().body(response);
		} else {
			response.setSuccess(false);
			response.setMessage("Application Error");
			response.setCode("99");
			return ResponseEntity.status(500).body(response);
		}
		
	} // // End of addUserInfo Api
	
	@RequestMapping(value="/changeUserInfo", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> editUser(@RequestBody UserInfoRequestObj userRequestObj,Principal principal) {
		
		//Check AccessToken &&  client validation
		CommonGetResponse resp = new CommonGetResponse();
		
			
			UserSystemsRole userSystemRole = null;
			UserInfoRequest userRequest = userRequestObj.getUserInfo();
			User user = userRepository.findByUserLogId(userRequest.getUserId());
			try {
				
			    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
			    if(userRequest.getUseApplyStartDate()!=null || userRequest.getUseApplyStartDate()!="") {
			    	java.util.Date date = dateFormat.parse(userRequest.getUseApplyStartDate());
			    	java.sql.Date sqlStartDate = new java.sql.Date(date.getTime());
			    	user.setApplyStartDate(sqlStartDate);
			    }
			    if(userRequest.getUseApplyEndDate()!=null || userRequest.getUseApplyEndDate()!="") {
			    	java.util.Date date = dateFormat.parse(userRequest.getUseApplyEndDate());
			    	java.sql.Date sqlEndDate = new java.sql.Date(date.getTime());
			    	user.setApplyEndDate(sqlEndDate);
			    }
			} catch(Exception e) {
			     System.out.println("Date Format Exception:"+e.getMessage());
			}
			if(userRequest.getEmailAddress()!=null || userRequest.getEmailAddress()!="") {
				user.setEmail(userRequest.getEmailAddress());
			}
			boolean isUseBool = userRequest.getUseYn();
			if(isUseBool) {
				user.setIsUse(1L);
			} else {
				user.setIsUse(0L);
			}
			user.setMobile(Long.parseLong(userRequest.getMobileNo()));
			user.setTelephone_No(Long.parseLong(userRequest.getTelNo()));
			user.setUserLogId(userRequest.getUserId());
			user.setUserName(userRequest.getUserNm());			
			User user1 = userRepository.save(user);
			if(user1==null) {
				resp.setIsSuccess(false);
				resp.setMessage("Application Error");
				resp.setErrorCode("99");
				return  ResponseEntity.status(200).body(resp);	
			}
			resp.setIsSuccess(true);
			resp.setMessage("User Info Changes Successfull");
			resp.setErrorCode("200");
			return  ResponseEntity.status(200).body(resp);
		
		/*for (String systemRoleId : systemRoleIds) {
			boolean isSystemRoleExist = userSystemsRoleRepository.existsById(Long.parseLong(systemRoleId));
			//List<Long> existsystemIds = userSystemsRoleRepository.getSystemIdByUserId(user1.getUserId());
			if(isSystemRoleExist) {
			} else {
				userSystemRole = new UserSystemsRole();
				systemRoleEntity = new SystemsRole();
				systemRoleEntity = systemsRoleRepository.getOne(Long.parseLong(systemRoleId));
				userSystemRole.setSystemRole(systemRoleEntity);
				if(isUseBool) {
					userSystemRole.setIsUse(1);
				} else {
					userSystemRole.setIsUse(0);
				}
				usrStatus = userSystemsRoleRepository.save(userSystemRole);
			}
		}*/		
	} // End of changeUserInfo Api
	
	@RequestMapping(value="/addSystemOtp", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> addSystemOtp(@RequestBody SystemOtpRequest systemOtp) {
		SystemOtp systemOtpEntity;
		SystemOtp sysOtpExist = null;
		CommonResponse response = new CommonResponse();
				systemOtpEntity = new SystemOtp();
				String[] systemIds = systemOtp.getSystemId();
				for(String systemId:systemIds) {		
				Systems systemsObj = systemsRepository.getOne(Long.parseLong(systemId));
				systemOtpEntity.setSystems(systemsObj);
				systemOtpEntity.setIpaddress(systemOtp.getIpAddress());
				systemOtpEntity.setDescription(systemOtp.getDescription());
				sysOtpExist = systemOtpRepository.save(systemOtpEntity);
				}
				response.setSuccess(true);
				response.setMessage("System OTP Saved Successfully");
				response.setCode("200");
				return  ResponseEntity.ok().body(response);		
	}
	
	@RequestMapping(value="/editSystemOtp", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> editSystemOtp(@RequestBody SystemOtpRequest systemOtp) {
		SystemOtp systemOtpEntity;
		SystemOtp sysOtpExist = null;
		Long systemOtpId = Long.parseLong(systemOtp.getSystemOtpId());
		SystemOtp existSystemOtp = systemOtpRepository.getOne(systemOtpId);
		CommonResponse response = new CommonResponse();
		systemOtpEntity = new SystemOtp();
		String[] systemIds = systemOtp.getSystemId();
		for(String systemId:systemIds) {		
		Systems systemsObj = systemsRepository.getOne(Long.parseLong(systemId));
		existSystemOtp.setSystems(systemsObj);
		existSystemOtp.setIpaddress(systemOtp.getIpAddress());
		existSystemOtp.setDescription(systemOtp.getDescription());
		sysOtpExist = systemOtpRepository.save(existSystemOtp);
		}
		response.setSuccess(true);
		response.setMessage("System OTP Updated Successfully");
		response.setCode("200");
		return  ResponseEntity.ok().body(response);		
	}
	
	@RequestMapping(value="/setRoleInfo", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<CommonResponse> setRoleInfo(@RequestBody SetRoleRequest roleRequest) {
		
		CommonResponse response = new CommonResponse();
		String systemRoleId = roleRequest.getSystemRoleId();
		boolean isUseBool = roleRequest.isUseYn();
		if(systemRoleId!=null) {
			SystemsRole existSystemRoleEntity = systemsRoleRepository.getOne(Long.parseLong(roleRequest.getSystemRoleId()));
			existSystemRoleEntity.setDescription(roleRequest.getDescription());
			if(isUseBool) {
				existSystemRoleEntity.setIs_use(1L);
			} else {
				existSystemRoleEntity.setIs_use(0L);
			}
			systemsRoleRepository.save(existSystemRoleEntity);
			response.setSuccess(true);
			response.setMessage("Update success");
			response.setCode("200");
			return  ResponseEntity.ok().body(response);
		} else {
				// Register SET ROLE to SYSTEMS
			List<Long> systemRoleIdExist;
			List<BigInteger>  roleIdsExists =roleRepository.getRoleByNo(Long.parseLong(roleRequest.getWorkGrpNo()));
			for(BigInteger roleId: roleIdsExists) {
				systemRoleIdExist = systemsRoleRepository.getEntityBySystemIdWrkGroup(Long.parseLong(roleRequest.getSystemId()),roleId.longValue());
				if(systemRoleIdExist.size()>0) {
						response.setSuccess(false);
						response.setMessage("WorkGrpNo is already Assigned to this System");
						response.setCode("200");
						return  ResponseEntity.status(200).body(response);
				}
			}
			SystemsRole systemRole = new SystemsRole();
			List<Role> role = roleRepository.getSystemRoleByNameNo(roleRequest.getWorkGrpNo());
			//get System info
			Systems systemEntity = systemsRepository.getOne(Long.parseLong(roleRequest.getSystemId()));
			systemRole.setSystem(systemEntity);
			systemRole.setRole(role.get(0));
			systemRole.setDescription(roleRequest.getDescription());
			if(isUseBool) {
				systemRole.setIs_use(1L);
			} else {
				systemRole.setIs_use(0L);
			}
			//save SystemRole entity
			SystemsRole systemRoleEntity = systemsRoleRepository.save(systemRole);
			
			if(systemRoleEntity!=null) {
				
				response.setSuccess(true);
				response.setMessage("Set Role success");
				response.setCode("200");
				return  ResponseEntity.ok().headers(respHeader).body(response);
			} else {
				response.setSuccess(false);
				response.setMessage("Set Role not success");
				response.setCode("200");
				return  ResponseEntity.status(200).body(response);
			}
				
		}
	} //// End of SetRoleInfo Api
	
	//Set Resource Info
		@RequestMapping(value="/setResourceInfo", method = RequestMethod.POST,
				consumes = "application/json", produces = "application/json")
		public ResponseEntity<CommonResponse> setResourceInfo(@RequestBody ResourceRequest resourceRequest) {
			
			CommonResponse response = new CommonResponse();
			String systemRoleId = resourceRequest.getSystemResourceId();
			boolean isUseBool = resourceRequest.isUseYn();
			if(systemRoleId!=null) {
				List<Resource> existResourceEntity = resourceRepository.getResourceByPath(resourceRequest.getResourcePath());
				Systems systemEntity = systemsRepository.getOne(Long.parseLong(resourceRequest.getSystemId()));
				SystemsResource checkSystemResource = systemsResourceRepository.getResourceBySystemId(existResourceEntity.get(0).getResourceId(), systemEntity.getSystemId());
				if(isUseBool) {
					checkSystemResource.setIsUse(1L);
				} else {
					checkSystemResource.setIsUse(0L);
				}
				//checkSystemResource.se
				response.setSuccess(true);
				response.setMessage("Set Resource success");
				response.setCode("200");
				return  ResponseEntity.ok().body(response);
				// Assign Resource to System
				
			} else {
				SystemsResource systemResource = new SystemsResource();
				//yet to start
				List<Resource> existResourceEntity = resourceRepository.getResourceByPath(resourceRequest.getResourcePath());
				System.out.println("Resource List:"+existResourceEntity.size());
				if(existResourceEntity.size()>0) {
					//get System info
					Systems systemEntity = systemsRepository.getOne(Long.parseLong(resourceRequest.getSystemId()));
					systemResource.setSystem(systemEntity);
					existResourceEntity.get(0).setDescription(resourceRequest.getResourceDesc());
					systemResource.setResource(existResourceEntity.get(0));
					if(isUseBool) {
						systemResource.setIsUse(1L);
					} else {
						systemResource.setIsUse(0L);
					}
					//save SystemRole entity
					SystemsResource systemResourceEntity = systemsResourceRepository.save(systemResource);
					if(systemResourceEntity!=null) {				
						response.setSuccess(true);
						response.setMessage("Set Resource success");
						response.setCode("200");
						return  ResponseEntity.ok().headers(respHeader).body(response);
					} else {
						response.setSuccess(false);
						response.setMessage("Set Resource not success");
						response.setCode("99");
						return  ResponseEntity.status(200).body(response);
					}
				} else {
					Resource resource = new Resource();
					resource.setPath(resourceRequest.getResourcePath());
					resource.setDescription(resourceRequest.getResourceDesc());
					
					if(isUseBool) {
						resource.setIsUse(1L);
					} else {
						resource.setIsUse(0L);
					}
					//save Role entity
					Resource resourceEntity = resourceRepository.save(resource);
					if(resourceEntity!=null) {
						//get System info
						Systems systemEntity = systemsRepository.getOne(Long.parseLong(resourceRequest.getSystemId()));
						systemResource.setSystem(systemEntity);
						systemResource.setResource(resourceEntity);
						if(isUseBool) {
							systemResource.setIsUse(1L);
						} else {
							systemResource.setIsUse(0L);
						}
						//save SystemRole entity
						SystemsResource systemResourceEntity = systemsResourceRepository.save(systemResource);
						
						if(systemResourceEntity!=null) {
							
							response.setSuccess(true);
							response.setMessage("Set Resource success");
							response.setCode("200");
							return  ResponseEntity.ok().body(response);
						} else {
							response.setSuccess(false);
							response.setMessage("Set Resource not success");
							response.setCode("99");
							return  ResponseEntity.status(500).body(response);
						}
					} else {
						response.setSuccess(false);
						response.setMessage("Set Resource not success");
						response.setCode("99");
						return  ResponseEntity.status(500).body(response);
					}
				}
			}
		} // End of SetResourceInfo Api
	
	
	
	@RequestMapping(value="/getAllUserInfo", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> getAllUserInfo(@RequestHeader HttpHeaders headers) {
		CommonGetInfoResponse response = new CommonGetInfoResponse();
		List<UserSystemsRole> usrList = new ArrayList<>();
		usrList = userSystemsRoleRepository.findAll();
		response.setDetails(usrList);
		response.setSuccess(true);
		if(usrList.size()>0) {
			response.setMessage("User Information success");
		} else {
			response.setMessage("No User information Available");
		}
		response.setCode("200");
		return  ResponseEntity.ok().body(response);
	}
	
	
	
	/*@RequestMapping(value="/getUserRole", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> getUserRole(Principal principal,@RequestHeader HttpHeaders headers) {
		
		CommonGetResponse resp = new CommonGetResponse();
		GetUserRoleObjResponse userRoleResponse = new GetUserRoleObjResponse();
		GetUserRoleObj roleObj = null;
		List<GetUserRoleObj> getUserRoleObjList = new ArrayList<>();
		List<String> clientIds = headers.getValuesAsList("clientId");
		List<String> clientSecrets = headers.getValuesAsList("clientSecret");
		
		Systems systems = systemsRepository.findSystemIdByClientIdSecret(clientIds.get(0),clientSecrets.get(0));
		if(systems==null) {
			resp.setIsSuccess(false);
			resp.setMessage("clientId or clientSecret invalid");
			resp.setErrorCode("9999");
			return  ResponseEntity.status(200).body(resp);
		}
		if (principal == null) {
			return null;
		}else {
			String userLogId = principal.getName();
			User user = userRepository.findByUserLogId(userLogId);
			List<BigInteger> systemRoleIds =  systemsRoleRepository.getSystemRoleIdbySystemId(systems.getSystemId());
			Long[] systemRoleIdsLong = new Long[systemRoleIds.size()];
			int i=0;
			for(BigInteger sysRoleId: systemRoleIds) {
				systemRoleIdsLong[i] = sysRoleId.longValue();
				i++;
			}
			List<Role> roleEntityList = userSystemsRoleRepository.getRolesBySystemRoleUserId(user.getUserId().toString(),systemRoleIdsLong);
			for (Role role : roleEntityList) {
				roleObj = new GetUserRoleObj();
				roleObj.setWorkGrpNo(role.getNumber().toString());
				getUserRoleObjList.add(roleObj);
			}
			userRoleResponse.setIsSuccess(true);
			userRoleResponse.setMessage("UserRole Available");
			userRoleResponse.setErrorCode("200");
			userRoleResponse.setWorkGrpNoList(getUserRoleObjList);
			return  ResponseEntity.status(200).body(userRoleResponse);
		}
	}*/
	
	
		
	@RequestMapping(value="/getAllSystem", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> getAllSystem(@RequestHeader HttpHeaders headers) {
		List<Systems> systemList = new ArrayList<>();
		systemList = systemsRepository.findAll();
		CommonGetInfoResponse response = new CommonGetInfoResponse();
		response.setDetails(systemList);
		response.setSuccess(true);
		if(systemList.size()>0) {
			response.setMessage("System  Information success");
		} else {
			response.setMessage("No Role information Available");
		}
		response.setCode("200");
		response.setAccessToken(headers.get("accessToken").get(0));
		return  ResponseEntity.ok().body(response);
	}
	
	@RequestMapping(value="/getAllSystemRole", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> getAllSystemRole(@RequestHeader HttpHeaders headers) {
		System.out.println("Hi");
		List<SystemsRole> systemRoleList = new ArrayList<>();
		systemRoleList = systemsRoleRepository.findAll();
		CommonGetInfoResponse response = new CommonGetInfoResponse();
		response.setDetails(systemRoleList);
		response.setSuccess(true);
		if(systemRoleList.size()>0) {
			response.setMessage("System Role Information success");
		} else {
			response.setMessage("No Role information Available");
		}
		response.setCode("200");
		response.setAccessToken(headers.get("accessToken").get(0));
		respHeader.add("accessToken", headers.get("accessToken").get(0));
		return  ResponseEntity.ok().headers(respHeader).body(response);
	}
	
	//Get All Resources which are assigned Systems 
		@RequestMapping(value="/getAllResource", method = RequestMethod.POST,
				consumes = "application/json", produces = "application/json")
		public ResponseEntity<CommonGetInfoResponse> getAllResource(@RequestHeader HttpHeaders headers) {
			List<SystemsResource> systemsResourceList = new ArrayList<>();
			systemsResourceList = systemsResourceRepository.findAll();
			CommonGetInfoResponse response = new CommonGetInfoResponse();
			response.setDetails(systemsResourceList);
			response.setSuccess(true);
			if(systemsResourceList.size()>0) {
				response.setMessage("System Resource Information success");
			} else {
				response.setMessage("No Resource information Available");
			}
			response.setCode("200");
			response.setAccessToken(headers.get("accessToken").get(0));
			respHeader.add("accessToken", headers.get("accessToken").get(0));
			return  ResponseEntity.ok().headers(respHeader).body(response);
		}
		
	
	
		// Assign system Resource to user who belongs
	@RequestMapping(value="/setUserResource", method = RequestMethod.POST,
	consumes = "application/json", produces = "application/json")
	public ResponseEntity<CommonGetInfoResponse> assignResourceToUser(@RequestHeader HttpHeaders headers, @RequestBody SetUserSystemResource userSystemResource) {
		
		
		Long usrid = Long.parseLong(userSystemResource.getUserSystemRoleId());
		List<UserSystemResource> userSystemRepoEntityList = userSystemsResourceRepository.getUserSystemResourceByUser(usrid);
		if(userSystemRepoEntityList.size()>0) {
			System.out.println("Delete");
			for (UserSystemResource userSystemResource2 : userSystemRepoEntityList) {
				userSystemsResourceRepository.delete(userSystemResource2);
			}
		}		
		String userSystemRoleId = userSystemResource.getUserSystemRoleId();
		String[] systemResourceIds = userSystemResource.getSystemResourceId();
		UserSystemsRole userSystemRoleEntity = userSystemsRoleRepository.getOne(Long.parseLong(userSystemRoleId));
		UserSystemResource usrStatus = null;
		for(String systemResourceId: systemResourceIds) {
			UserSystemResource userSystemResourceEntity = new UserSystemResource();
			SystemsResource systemResourceEntity = systemsResourceRepository.getOne(Long.parseLong(systemResourceId));
			userSystemResourceEntity.setUsersystemRole(userSystemRoleEntity);
			userSystemResourceEntity.setSystemResource(systemResourceEntity);
			usrStatus = userSystemsResourceRepository.save(userSystemResourceEntity);
		}
		CommonGetInfoResponse response = new CommonGetInfoResponse();
		response.setSuccess(true);
		if(usrStatus!=null) {
			response.setMessage("Assign UserResource success");
			response.setCode("200");
			response.setAccessToken(headers.get("accessToken").get(0));
			respHeader.add("accessToken", headers.get("accessToken").get(0));
			return  ResponseEntity.ok().headers(respHeader).body(response);
		} else {
			response.setSuccess(false);
			response.setMessage("Assign UserResource not success");
			response.setCode("99");
			return  ResponseEntity.ok().headers(respHeader).body(response);
		}
	}
	
	// Assign system Resource to user who belongs
	@RequestMapping(value="/setRoleResource", method = RequestMethod.POST,
	consumes = "application/json", produces = "application/json")
	public ResponseEntity<CommonGetInfoResponse> assignSystemResourceToRole(@RequestHeader HttpHeaders headers, @RequestBody SetUserSystemResource userSystemResource) {
		
		
		Long systemRoleId = Long.parseLong(userSystemResource.getUserSystemRoleId());
		List<RoleSystemResource> roleSystemRepoEntityList = roleSystemsResourceRepository.getRoleSystemResourceByRole(systemRoleId);
		if(roleSystemRepoEntityList.size()>0) {
			System.out.println("Delete");
			for (RoleSystemResource roleSystemResource2 : roleSystemRepoEntityList) {
				roleSystemsResourceRepository.delete(roleSystemResource2);
			}
		}		
		String[] systemResourceIds = userSystemResource.getSystemResourceId();
		SystemsRole systemRoleEntity = systemsRoleRepository.getOne(systemRoleId);
		RoleSystemResource usrStatus = null;
		for(String systemResourceId: systemResourceIds) {
			RoleSystemResource roleSystemResourceEntity = new RoleSystemResource();
			SystemsResource systemResourceEntity = systemsResourceRepository.getOne(Long.parseLong(systemResourceId));
			roleSystemResourceEntity.setSystemRole(systemRoleEntity);
			roleSystemResourceEntity.setSystemResource(systemResourceEntity);
			usrStatus = roleSystemsResourceRepository.save(roleSystemResourceEntity);
		}
		CommonGetInfoResponse response = new CommonGetInfoResponse();
		response.setSuccess(true);
		if(usrStatus!=null) {
			response.setMessage("Assign Role Resource success");
			response.setCode("200");
			return  ResponseEntity.ok().body(response);
		} else {
			response.setSuccess(false);
			response.setMessage("Assign Role Resource not success");
			response.setCode("99");
			return  ResponseEntity.ok().body(response);
		}
	}
	
	// Get Resources which are assigned to user
	@RequestMapping(value="/getUserResourceUAS", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<CommonGetInfoResponse> getUserResourceUAS(@RequestBody GetInfoMinimulRequest getInfoRequest) {
		String userSystemRoleId = getInfoRequest.getId();
		List<Resource> resourceList = userSystemsResourceRepository.getResourceByUserId(userSystemRoleId);
		CommonGetInfoResponse response = new CommonGetInfoResponse();
		response.setDetails(resourceList);
		response.setSuccess(true);
		if(resourceList.size()>0) {
			response.setMessage("User Resource Available");
			response.setCode("200");
			return  ResponseEntity.ok().headers(respHeader).body(response);
		} else {
			response.setMessage("User Resource Not Available");
			response.setCode("200");
			return  ResponseEntity.ok().headers(respHeader).body(response);
		}
	}
	
	// Get Resources which are assigned particular Role(BO-1111)
	@RequestMapping(value="/getRoleResourceUAS", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<CommonGetInfoResponse> getRoleResourceUAS(@RequestBody GetInfoMinimulRequest getInfoRequest) {
		String systemRoleId = getInfoRequest.getId();
		List<SystemsResource> resourceList = roleSystemsResourceRepository.getResourceByRoleId(systemRoleId);
		CommonGetInfoResponse response = new CommonGetInfoResponse();
		response.setDetails(resourceList);
		response.setSuccess(true);
		if(resourceList.size()>0) {
			response.setMessage("User Resource Available");
			response.setCode("200");
			return  ResponseEntity.ok().headers(respHeader).body(response);
		} else {
			response.setMessage("User Resource Not Available");
			response.setCode("200");
			return  ResponseEntity.ok().headers(respHeader).body(response);
		}
	}
	
	//Get All Resources which are assigned to particular System 
	@RequestMapping(value="/getSystemResource", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<CommonGetInfoResponse> getSystemResource(@RequestBody GetInfoMinimulRequest getInfoRequest) {
		System.out.println("getSystemResource API Invokeds");
		List<SystemsResource> systemsResourceList = new ArrayList<>();
		String systemId = getInfoRequest.getId();
		systemsResourceList = systemsResourceRepository.getResourceBySystemId(systemId);
		CommonGetInfoResponse response = new CommonGetInfoResponse();
		response.setDetails(systemsResourceList);
		response.setSuccess(true);
		if(systemsResourceList.size()>0) {
			response.setMessage("System Resource Available");
			response.setCode("200");
			return  ResponseEntity.ok().body(response);
		} else {
			response.setMessage("System Resource Not Available");
			response.setCode("200");
			return  ResponseEntity.ok().headers(respHeader).body(response);
		}
	}
		
	@RequestMapping(value="/getUserSystem", method = RequestMethod.POST,
			consumes = "application/json", produces = "application/json")
	public ResponseEntity<CommonGetInfoResponse> getUserSystem(Principal principal,@RequestHeader HttpHeaders headers, @RequestBody GetInfoMinimulRequest getInfoRequest) {
		String systemId = getInfoRequest.getId();
		
		// get SystemRoleId using systemId
		List<BigInteger> systemRoleIds = systemsRoleRepository.getSystemRoleIdbySystemId(Long.parseLong(systemId));
		System.out.println("systemRoleId list:"+systemRoleIds);
		Long[] systemRoleIdsLong = new Long[systemRoleIds.size()];
		int i=0;
		for(BigInteger sysRoleId: systemRoleIds) {
			systemRoleIdsLong[i] = sysRoleId.longValue();
			i++;
		}
		List<User> userSystemRoleList = userSystemsRoleRepository.getUserBySystemId(systemRoleIdsLong);
		CommonGetInfoResponse response = new CommonGetInfoResponse();
		response.setDetails(userSystemRoleList);
		response.setSuccess(true);
		if(userSystemRoleList.size()>0) {
			response.setMessage("System Role Information success");
		} else {
			response.setMessage("No User Role information Available");
		}
		response.setCode("200");
		response.setAccessToken(headers.get("accessToken").get(0));
		respHeader.add("accessToken", headers.get("accessToken").get(0));
		return  ResponseEntity.ok().headers(respHeader).body(response);
	}
}
