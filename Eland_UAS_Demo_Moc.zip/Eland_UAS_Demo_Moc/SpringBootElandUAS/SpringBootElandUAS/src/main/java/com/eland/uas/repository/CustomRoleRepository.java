package com.eland.uas.repository;

import java.math.BigInteger;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.eland.uas.entity.Role;

@Repository
public interface CustomRoleRepository {
	
	List<Role> getSystemRoleByNameNo(Long wrkGrpNo, String wrkGrpName);
	List<Role> getSystemRoleByNameNo(String workGrpNo);	
	List<BigInteger> getRoleByNo(Long wrkGrpNo);
	List<Role> findRoleByNameNo(String name, Long number);	
	Role findRoleByNameNo(Long parseLong);
}
