package com.eland.uas.reqrespmodel;

public class PasswordRequestResp {

	private String userPwOld;
	private String userPwNew;
	public String getUserPwOld() {
		return userPwOld;
	}
	public void setUserPwOld(String userPwOld) {
		this.userPwOld = userPwOld;
	}
	public String getUserPwNew() {
		return userPwNew;
	}
	public void setUserPwNew(String userPwNew) {
		this.userPwNew = userPwNew;
	}
}
