package com.eland.uas.repository;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.eland.uas.entity.Systems;

@Repository
@Transactional(readOnly = true)
public class CustomSystemRepositoryImpl implements CustomSystemRepository{

	@PersistenceContext
	EntityManager entityManager;

	@Override
	public Systems findSystemIdByClientIdSecret(String clientId, String clientSecret) {
		Query query = entityManager.createNativeQuery("select * from system where client_id='"+clientId+"' and client_secret='"+clientSecret+"'", Systems.class);
		Systems system = null;
		try {
			system = (Systems) query.getSingleResult();
		} catch (Exception e) {
			e.printStackTrace();
			return system;
		}
		return system;
	}
	
	
}
