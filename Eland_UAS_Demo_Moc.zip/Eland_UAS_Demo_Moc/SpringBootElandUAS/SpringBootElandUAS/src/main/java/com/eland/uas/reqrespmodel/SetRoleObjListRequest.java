package com.eland.uas.reqrespmodel;

import java.util.List;

public class SetRoleObjListRequest {

	private List<SetRoleObj> roleInfoList;

	public List<SetRoleObj> getRoleInfoList() {
		return roleInfoList;
	}

	public void setRoleInfoList(List<SetRoleObj> roleInfoList) {
		this.roleInfoList = roleInfoList;
	}
	
	
}
