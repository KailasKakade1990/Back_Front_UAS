package com.eland.uas.reqrespmodel;

public class RoleRequest {

	private String systemRoleId;
	private String systemId;
	private Long workGrpNo;
	private String workGrpName;
	private String description;
	private boolean useYn;
	
	public String getSystemRoleId() {
		return systemRoleId;
	}
	public void setSystemRoleId(String systemRoleId) {
		this.systemRoleId = systemRoleId;
	}
	public String getSystemId() {
		return systemId;
	}
	public void setSystemId(String systemId) {
		this.systemId = systemId;
	}
	public Long getWorkGrpNo() {
		return workGrpNo;
	}
	public void setWorkGrpNo(Long workGrpNo) {
		this.workGrpNo = workGrpNo;
	}
	public String getWorkGrpName() {
		return workGrpName;
	}
	public void setWorkGrpName(String workGrpName) {
		this.workGrpName = workGrpName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public boolean isUseYn() {
		return useYn;
	}
	public void setUseYn(boolean useYn) {
		this.useYn = useYn;
	}	
}
