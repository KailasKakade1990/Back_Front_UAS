package com.eland.uas.config;

public class Configuration {

}
