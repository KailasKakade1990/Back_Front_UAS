package com.eland.uas.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.eland.uas.entity.Resource;
import com.eland.uas.entity.Role;
import com.eland.uas.entity.UserSystemResource;

@Repository
@Transactional(readOnly = true)
public class CustomUserSystemResourceRespositoryImpl implements CustomUserSystemResourceRespository{
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public List<Resource> getResourceByUserId(String userSystemRoleId) {
		Query query = entityManager.createNativeQuery("select * from resource r inner join system_resource sr on(r.resource_id=sr.resource_id) inner join user_system_resource usr on(sr.system_resource_id=usr.system_resource_id) where usr.user_system_role_id="+userSystemRoleId+" ", Resource.class);
		//query.getResultList();
		  return query.getResultList();
	}

	@Override
	public List<Role> getSystemRolesByUserId(String userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<UserSystemResource> getUserSystemResourceByUser(Long usrid) {
		Query query = entityManager.createNativeQuery("select * from user_system_resource where user_system_role_id="+usrid+"", UserSystemResource.class);
		//query.getResultList();
		  return query.getResultList();
	}
	
	/*public List<SystemsResource> getResourceByUserId(String userSystemRoleId) {
		Query query = entityManager.createNativeQuery("	select * from system_resource sr inner join system s on(sr.system_id=s.system_id) inner join resource r on(r.resource_id=sr.resource_id) inner join user_system_resource usr on(sr.system_resource_id=usr.system_resource_id) where usr.user_system_role_id="+userSystemRoleId+"; ", SystemsResource.class);
		//query.getResultList();
		  return query.getResultList();
	}*/
	
}
