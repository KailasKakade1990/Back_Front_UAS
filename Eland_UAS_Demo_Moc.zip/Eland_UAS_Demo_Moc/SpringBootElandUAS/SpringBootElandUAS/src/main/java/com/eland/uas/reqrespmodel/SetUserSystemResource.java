package com.eland.uas.reqrespmodel;

public class SetUserSystemResource {

	private String[] systemResourceId;
	private String userSystemRoleId;
	
	public String[] getSystemResourceId() {
		return systemResourceId;
	}
	public void setSystemResourceId(String[] systemResourceId) {
		this.systemResourceId = systemResourceId;
	}
	public String getUserSystemRoleId() {
		return userSystemRoleId;
	}
	public void setUserSystemRoleId(String userSystemRoleId) {
		this.userSystemRoleId = userSystemRoleId;
	}
	
	
}
