package com.eland.uas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.eland.uas.entity.SystemResourceRole;

public interface SystemResourceRoleRepository extends JpaRepository<SystemResourceRole, Long>{

}
