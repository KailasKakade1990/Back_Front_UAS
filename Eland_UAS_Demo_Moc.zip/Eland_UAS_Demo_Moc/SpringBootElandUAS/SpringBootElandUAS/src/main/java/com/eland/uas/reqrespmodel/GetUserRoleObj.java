package com.eland.uas.reqrespmodel;

public class GetUserRoleObj {

	private String workGrpNo;

	public String getWorkGrpNo() {
		return workGrpNo;
	}

	public void setWorkGrpNo(String workGrpNo) {
		this.workGrpNo = workGrpNo;
	}
}
