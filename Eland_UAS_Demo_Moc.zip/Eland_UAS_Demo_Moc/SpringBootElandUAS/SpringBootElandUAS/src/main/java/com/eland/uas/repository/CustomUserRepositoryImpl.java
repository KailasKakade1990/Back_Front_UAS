package com.eland.uas.repository;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.eland.uas.entity.User;

@Repository("CustomUserRespository")
@Transactional(readOnly = true)
public class CustomUserRepositoryImpl implements CustomUserRespository {

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public Long getMaxByAccountNo(String userName) {
		System.out.println("***");
		Query query = entityManager.createNativeQuery("SELECT account_no FROM user where user_name='"+userName+"' ");
		Long accountNo = null;
		try {  
			accountNo = (Long) query.getSingleResult();
			return accountNo;
		} catch(Exception e) {
			return accountNo;
		}
	}

	@Override
	public User getUserByUserName(String userName) {
		Query query = entityManager.createNativeQuery("SELECT * FROM user where user_name='"+userName+"'", User.class);
		User user = null;
		try {  
			user = (User) query.getSingleResult();
			return user;
		} catch(Exception e) {
			return user;
		}
	}

	@Override
	public List<Long> getAccountNoByUserName(String userName) {
		System.out.println("getAccountNoByUserNameTest Impl invoked");
		Query query = entityManager.createNativeQuery("SELECT account_no FROM user where user_name='"+userName+"' group by account_no", Long.class);
		List<Long> accountNoList = new ArrayList<Long>();
		Long accNo;
		try {  
			accNo = (Long) query.getSingleResult();
			accountNoList.add(accNo);
			return accountNoList;
		} catch(Exception e) {
			return accountNoList;
		}
	}
}
