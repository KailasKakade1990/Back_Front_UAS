package com.eland.uas.repository;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.eland.uas.entity.Resource;
import com.eland.uas.entity.Role;
import com.eland.uas.entity.SystemsResource;
import com.eland.uas.entity.UserSystemResource;
@Repository
public interface CustomUserSystemResourceRespository {

	List<Resource> getResourceByUserId(String userSystemRoleId);
	List<Role> getSystemRolesByUserId(String userId);
	List<UserSystemResource> getUserSystemResourceByUser(Long usrid);
}
