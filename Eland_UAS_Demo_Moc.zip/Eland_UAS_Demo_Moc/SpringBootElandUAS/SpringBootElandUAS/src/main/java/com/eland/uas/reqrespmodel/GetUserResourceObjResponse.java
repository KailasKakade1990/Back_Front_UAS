package com.eland.uas.reqrespmodel;

public class GetUserResourceObjResponse {

	private boolean isSuccess;
	private String message;
	private String errorCode;
	private Object resourceList;
	
	public boolean isSuccess() {
		return isSuccess;
	}
	public void setSuccess(boolean isSuccess) {
		this.isSuccess = isSuccess;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public Object getResourceList() {
		return resourceList;
	}
	public void setResourceList(Object resourceList) {
		this.resourceList = resourceList;
	}
	
}
