package com.eland.uas.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.eland.uas.entity.Resource;
import com.eland.uas.entity.SystemsResource;

@Repository
@Transactional(readOnly = true)
public class CustomResourceRespositoryImpl implements CustomResourceRespository {


	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public List<Resource> getResourceByPath(String resourcePath) {
		// TODO Auto-generated method stub
		Query query = entityManager.createNativeQuery("select * from resource where path='"+resourcePath+"'", Resource.class);
		//query.getResultList();
		  return query.getResultList();
	}

}
