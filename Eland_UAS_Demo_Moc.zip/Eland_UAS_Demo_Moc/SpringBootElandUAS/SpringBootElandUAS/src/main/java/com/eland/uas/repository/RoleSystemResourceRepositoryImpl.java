package com.eland.uas.repository;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import org.springframework.transaction.annotation.Transactional;

import org.springframework.stereotype.Repository;

import com.eland.uas.entity.Resource;
import com.eland.uas.entity.RoleSystemResource;
import com.eland.uas.entity.SystemsResource;

@Repository
@Transactional(readOnly = true)
public class RoleSystemResourceRepositoryImpl implements CustomRoleSystemResourceRepository{

	@PersistenceContext
	EntityManager entityManager;
	
	@Override
	public List<SystemsResource> getResourceByRoleId(String systemRoleId) {
		
		Query query = entityManager.createNativeQuery("select * from resource r inner join system_resource sr on(r.resource_id=sr.resource_id) inner join role_system_resource rsr on(sr.system_resource_id=rsr.system_resource_id) where rsr.system_role_id="+systemRoleId+" ", SystemsResource.class);
		//query.getResultList();
		  return query.getResultList();
	}

	@Override
	public List<RoleSystemResource> getRoleSystemResourceByRole(Long systemRoleId) {
		Query query = entityManager.createNativeQuery("select * from role_system_resource where system_role_id="+systemRoleId+" ", RoleSystemResource.class);
		//query.getResultList();
		  return query.getResultList();
	}
}
