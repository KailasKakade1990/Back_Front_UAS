package com.eland.uas.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "system_resource_role")
public class SystemResourceRole {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "system_resource_role_id")
	private Long systemResourceRoleid;
	
	@ManyToOne
	@JoinColumn(name = "system_role_id")
	private SystemsRole systemRole;
	
	@ManyToOne
	@JoinColumn(name = "system_resource_id")
	private SystemsResource systemResource;
	
	
	public Long getSystemResourceRoleid() {
		return systemResourceRoleid;
	}

	public void setSystemResourceRoleid(Long systemResourceRoleid) {
		this.systemResourceRoleid = systemResourceRoleid;
	}

	public SystemsRole getSystemRole() {
		return systemRole;
	}

	public void setSystemRole(SystemsRole systemRole) {
		this.systemRole = systemRole;
	}

	public SystemsResource getSystemResource() {
		return systemResource;
	}

	public void setSystemResource(SystemsResource systemResource) {
		this.systemResource = systemResource;
	}
}
