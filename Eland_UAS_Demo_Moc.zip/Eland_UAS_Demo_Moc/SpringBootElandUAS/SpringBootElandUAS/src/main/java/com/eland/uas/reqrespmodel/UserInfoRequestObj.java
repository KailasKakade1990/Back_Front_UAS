package com.eland.uas.reqrespmodel;

public class UserInfoRequestObj {

	private UserInfoRequest userInfo;

	public UserInfoRequest getUserInfo() {
		return userInfo;
	}

	public void setUserInfo(UserInfoRequest userInfo) {
		this.userInfo = userInfo;
	}
}
