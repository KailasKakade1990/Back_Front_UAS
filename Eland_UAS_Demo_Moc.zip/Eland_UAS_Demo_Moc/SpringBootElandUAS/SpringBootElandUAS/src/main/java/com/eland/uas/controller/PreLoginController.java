package com.eland.uas.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.eland.uas.UserRepository1;
import com.eland.uas.service.PreLoginUserService;


@RestController
@RequestMapping
public class PreLoginController {

	private static final Logger logger = LoggerFactory.getLogger(PreLoginController.class);

	@Autowired
	private PreLoginUserService userService;
	
	@Autowired
	private UserRepository1 userRepo;

//	@PostMapping("/registration")
//	public ResponseEntity<Response> registration( @RequestBody User user,Principal principle) {
//		logger.info("register the User Info:");
//		if (principle != null) {
//			try {
//				String userid=principle.getName();
//				//System.out.println("user name======"+username);
//				//User user1=userRepo.findByUserId(userid);
//				//
//				
////					user.setSystemobj(new SystemPojo(systempkid));
////					user.setUserStatus(true);
////					user.setRole(new Role(roleId));
////					user.setApplicationRole("USER");
//					User dbUser = userService.save(user);
//					
//					return new ResponseEntity<>(new Response("User Is Save Successfully"), HttpStatus.OK);
//				
//			}catch(Exception e) {
//				//throw new DuplicateValueException(e.getMessage());
//				return new ResponseEntity<>(new Response("UserId already present"), HttpStatus.BAD_REQUEST);
//			}
//			
//		}else {
//			return new ResponseEntity<>(new Response("Unauthorized request "), HttpStatus.UNAUTHORIZED);
//		}
//
//	}

//	@PostMapping("/adminregistration")
//	public ResponseEntity<Response> adminRegistration(@RequestBody User user) {
//		logger.info("register the User Info:");
//		try {
//			
//			
//
//			User dbUser = userService.save(user);
//
//			return new ResponseEntity<>(new Response("User Is Save Successfully"), HttpStatus.OK);
//		}catch(Exception e){
//			return new ResponseEntity<>(new Response("UserId Already exist"), HttpStatus.BAD_REQUEST);
//		}
//		
//
//	}

}
