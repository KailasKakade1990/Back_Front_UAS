package com.eland.uas.reqrespmodel;

public class SetRoleObj {

	private String workGrpNo;
	private String workGrpDesc;
	private Boolean useYn;
	
	public String getWorkGrpNo() {
		return workGrpNo;
	}
	public void setWorkGrpNo(String workGrpNo) {
		this.workGrpNo = workGrpNo;
	}
	public String getWorkGrpDesc() {
		return workGrpDesc;
	}
	public void setWorkGrpDesc(String workGrpDesc) {
		this.workGrpDesc = workGrpDesc;
	}
	public Boolean getUseYn() {
		return useYn;
	}
	public void setUseYn(Boolean useYn) {
		this.useYn = useYn;
	}
	
}
