package com.eland.uas.reqrespmodel;

public class SetResourceObj {

	private String resourcePath;
	private String resourceDesc;
	private Boolean useYn;
	
	public String getResourcePath() {
		return resourcePath;
	}
	public void setResourcePath(String resourcePath) {
		this.resourcePath = resourcePath;
	}
	public String getResourceDesc() {
		return resourceDesc;
	}
	public void setResourceDesc(String resourceDesc) {
		this.resourceDesc = resourceDesc;
	}
	public Boolean getUseYn() {
		return useYn;
	}
	public void setUseYn(Boolean useYn) {
		this.useYn = useYn;
	}
	
	
}
