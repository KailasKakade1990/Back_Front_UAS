package com.eland.uas.repository;

import org.springframework.stereotype.Repository;

import com.eland.uas.entity.Systems;

@Repository
public interface CustomSystemRepository {

	Systems findSystemIdByClientIdSecret(String clientId, String clientSecret);

}
