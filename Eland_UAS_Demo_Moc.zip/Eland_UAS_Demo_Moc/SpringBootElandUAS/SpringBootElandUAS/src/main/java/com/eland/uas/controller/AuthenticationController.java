package com.eland.uas.controller;

import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.eland.uas.entity.Otp;
import com.eland.uas.entity.SystemOtp;
import com.eland.uas.entity.User;
//import com.eland.uas.enitiy.
import com.eland.uas.entity.UserSystemsRole;
import com.eland.uas.repository.OtpRepository;
import com.eland.uas.repository.SystemOtpRepository;
import com.eland.uas.repository.SystemsRespository;
import com.eland.uas.repository.UserSystemsRoleRepository;
import com.eland.uas.reqrespmodel.CommonResponse;
import com.eland.uas.security.JwtTokenUtil;
import com.eland.uas.security.JwtUser;
import com.eland.uas.service.OtpService;
import com.eland.uas.service.PreLoginUserService;

@RestController
@RequestMapping
public class AuthenticationController {

	@Value("${jwt.header}")
	private String tokenHeader;

	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtTokenUtil jwtTokenUtil;

	@Autowired
	private PreLoginUserService userService;

	@Autowired
	UserSystemsRoleRepository userSystemRoleRepository;

	@Autowired
	SystemsRespository systemRepository;

	@Autowired
	SystemOtpRepository systemotpRepository;

	@Autowired
	OtpRepository otpRepository;
	@Autowired
	OtpService otpService;
	/*
	 * @Autowired private SystemOtpRepository systemOtpRepository;
	 */

	// in post login @RequestHeader String clientId, @RequestHeader String
	// clientSecret

	// @PostMapping("/login")
	@RequestMapping(value = "/login", method = RequestMethod.POST, consumes = "application/json", produces = "application/json")
	public ResponseEntity<?> login(@RequestBody User user, HttpServletRequest request, HttpServletResponse response) {
		System.out.println("Login API Invoked..");
		CommonResponse resp = new CommonResponse();
		HttpHeaders respHeader = new HttpHeaders();
		try {

			// validate header clientId & clientSecret encoded value with db.
			Authentication authentication = authenticationManager
					.authenticate(new UsernamePasswordAuthenticationToken(user.getUserLogId(), user.getPassword()));
			final JwtUser userDetails = (JwtUser) authentication.getPrincipal();
			SecurityContextHolder.getContext().setAuthentication(authentication);

			/*
			 * String clientId = (String) request.getAttribute("clientId"); String
			 * clientSecret = (String) request.getAttribute("clientSecret");
			 * 
			 * Systems systems =
			 * systemRepository.findSystemIdByClientIdSecret(clientId,clientSecret);
			 * if(systems==null) { resp.setSuccess(false);
			 * resp.setMessage("clientId or clientSecret invalid"); resp.setCode("9999");
			 * return ResponseEntity.status(200).headers(respHeader).body(resp); }
			 */
			final String token11 = jwtTokenUtil.generateToken(userDetails);
			// response.setHeader("accessToken", token11);
			Long userid = userDetails.getUser().getUserId();
			UserSystemsRole userSystemsRoleobj = userSystemRoleRepository.findByUserUserId(userid);
			// SystemOtp= systemOtpRepository
			// Systems
			// systemOtp=systemRepository.findById(userSystemsRoleobj.getSystem().getSystemId()).orElse(new
			// Systems());

			byte[] encodedBytesClientID = Base64
					.encodeBase64(userSystemsRoleobj.getSystemRole().getSystem().getClientId().getBytes());
			byte[] encodedBytesClientSecret = Base64
					.encodeBase64(userSystemsRoleobj.getSystemRole().getSystem().getClientSecret().getBytes());

			// System.out.println("encodedBytes " + new String(encodedBytes));
			// byte[] decodedBytes = Base64.decodeBase64(encodedBytes);
			// System.out.println("decodedBytes " + new String(decodedBytes));
			// Encode using base 64 for client id and client secret

			response.setHeader("clientid", encodedBytesClientID.toString());
			response.setHeader("secret", encodedBytesClientSecret.toString());

			Long isOTPUseLong = userSystemsRoleobj.getSystemRole().getSystem().getInOtpUse();
					//.getSystemRole().getSystem().getInOtpUse();
			String isOtpStr = isOTPUseLong.toString();
			SystemOtp systemOtp = systemotpRepository.findByIpAddressAndSystemsSystemId(user.getIpaddress(),
					userSystemsRoleobj.getSystemRole().getSystem().getSystemId());
			if (isOtpStr.equals("1")) {
				Random r = new Random();
				String randomNumber = String.format("%04d", r.nextInt(1000000));
				String htmlData = "Your OTP is :" + randomNumber;
				userService.sendEmail(userDetails.getUser().getEmail(), "OTP for Eland UAS", htmlData);
				Otp otpObj = otpService.addOtp(randomNumber.toString(), userSystemsRoleobj.getUser(), systemOtp);

				// String otp = randomNumber.toString();
				// Long id=(long) 0;
				// systemotp.setId(id);
				// systemotp.setOtp(otp);
				// systemotp.setIpAddress("192.168.08.99");
				// systemotp.setSystemId(userSystemsRoleobj.getSystem().getName());
				// systemotp.setDescription("in office A");
				// systemotpRepository.save(systemotp);

				String ip = "182.71.254.118";
				// return new ResponseEntity<UserDTO>(new UserDTO(userDetails.getUser(),
				// message, ip), HttpStatus.OK);
				resp.setSuccess(true);
				resp.setMessage("Otp Generated Success");
				resp.setOtpUse(true);
				resp.setCode("200");
				resp.setAccessToken(token11);
				return ResponseEntity.ok().headers(respHeader).body(resp);
			} else if (isOtpStr.equals("0")) {
				String otpuse = "otp Use false";
				String ip = "182.71.254.118";
				// return new ResponseEntity<UserDTO>(new UserDTO(userDetails.getUser(), otpuse,
				// ip), HttpStatus.OK);
				resp.setSuccess(true);
				resp.setMessage("Login Success");
				resp.setCode("200");
				resp.setOtpUse(false);
				resp.setAccessToken(token11);
				respHeader.add("accessToken", token11);
				return ResponseEntity.ok().headers(respHeader).body(resp);
			} else {
				resp.setSuccess(false);
				resp.setMessage("Login not Success");
				resp.setCode("200");
				respHeader.add("accessToken", null);
				return ResponseEntity.ok().headers(respHeader).body(resp);
			}

		} catch (BadCredentialsException badCredential) {
			badCredential.printStackTrace();
			// throw new UnauthorizedException(e.getMessage());
			resp.setSuccess(false);
			resp.setMessage("userId or userPw invalid");
			resp.setCode("100");
			return ResponseEntity.status(200).headers(respHeader).body(resp);
		}

		catch (Exception e) {
			e.printStackTrace();
			// throw new UnauthorizedException(e.getMessage());
			resp.setSuccess(false);
			resp.setMessage("Application Error");
			resp.setCode("99");
			// return ResponseEntity.ok().headers(respHeader).body(resp);
			return ResponseEntity.status(200).headers(respHeader).body(resp);
		}
	}

}

// backup
/*
 * package com.eland.uas.controller;
 * 
 * import javax.servlet.http.HttpServletRequest; import
 * javax.servlet.http.HttpServletResponse;
 * 
 * import org.springframework.beans.factory.annotation.Autowired; import
 * org.springframework.beans.factory.annotation.Value; import
 * org.springframework.http.HttpStatus; import
 * org.springframework.http.ResponseEntity; import
 * org.springframework.security.authentication.AuthenticationManager; import
 * org.springframework.security.authentication.
 * UsernamePasswordAuthenticationToken; import
 * org.springframework.security.core.Authentication; import
 * org.springframework.security.core.context.SecurityContextHolder; import
 * org.springframework.web.bind.annotation.PostMapping; import
 * org.springframework.web.bind.annotation.RequestBody; import
 * org.springframework.web.bind.annotation.RequestMapping; import
 * org.springframework.web.bind.annotation.RestController;
 * 
 * import com.eland.uas.domain.UserDTO; import com.eland.uas.entity.User; import
 * com.eland.uas.exception.UnauthorizedException; import
 * com.eland.uas.security.JwtTokenUtil; import com.eland.uas.security.JwtUser;
 * 
 * @RestController
 * 
 * @RequestMapping public class AuthenticationController {
 * 
 * // private static final Logger logger = //
 * LoggerFactory.getLogger(AuthenticationController.class);
 * 
 * @Value("${jwt.header}") private String tokenHeader;
 * 
 * @Autowired private AuthenticationManager authenticationManager;
 * 
 * @Autowired private JwtTokenUtil jwtTokenUtil;
 * 
 * @PostMapping("/login") public ResponseEntity<UserDTO> login(@RequestBody User
 * user, HttpServletRequest request, HttpServletResponse response) {
 * 
 * try {
 * 
 * Authentication authentication = authenticationManager .authenticate(new
 * UsernamePasswordAuthenticationToken(user.getUserLogId(),
 * user.getPassword())); final JwtUser userDetails = (JwtUser)
 * authentication.getPrincipal();
 * SecurityContextHolder.getContext().setAuthentication(authentication); final
 * String token = jwtTokenUtil.generateToken(userDetails);
 * response.setHeader("Token", token); return new ResponseEntity<UserDTO>(new
 * UserDTO(userDetails.getUser(), token), HttpStatus.OK); } catch (Exception e)
 * { throw new UnauthorizedException(e.getMessage()); }
 * 
 * }
 * 
 * }
 */
